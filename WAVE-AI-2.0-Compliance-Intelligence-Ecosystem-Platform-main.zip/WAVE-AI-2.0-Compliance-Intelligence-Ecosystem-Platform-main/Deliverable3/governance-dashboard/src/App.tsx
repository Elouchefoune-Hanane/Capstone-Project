import HumanGovernanceModel from './components/HumanGovernanceModel'

function App() {
  return <HumanGovernanceModel />
}

export default App
