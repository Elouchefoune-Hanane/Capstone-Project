# Deliverable 3 — Human Governance Model Dashboard

https://claude.ai/public/artifacts/3f9641fa-7377-4595-8b7e-be86845df832

> AI-powered financial crime compliance dashboard for the **WIC × Microsoft AI Innovator Apprenticeship (2026)**

Visualizes the human governance model for the WAVE AI Investigator Co-Pilot — an opportunity matrix of AI-suitable tasks, an AI-verifying-AI check layer, a risk matrix, a RACI accountability model, and the end-to-end human-in-the-loop workflow with its three mandatory human checkpoints.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 19, TypeScript 6, Vite 8, Tailwind CSS 4, lucide-react |
| Backend | Node.js (ESM), Express 4 |
| Dev tooling | ESLint 10, Vite proxy, dotenv |

---

## Project Structure

```
Deliverable3/
├── server/                              # Express.js REST API
│   ├── index.js                         # Server entry point
│   └── package.json
└── governance-dashboard/                # React + Vite frontend
    ├── src/
    │   ├── components/
    │   │   └── HumanGovernanceModel.tsx  # Main dashboard component
    │   ├── App.tsx
    │   └── index.css                    # Tailwind entry point
    └── vite.config.ts                   # Dev proxy + Tailwind plugin config
```

---

## Architecture

- **Backend** (`Deliverable3/server/`): Node.js ESM module, Express 4, CORS locked to `http://localhost:5174`, dotenv for config. Runs on port `3002`.
- **Frontend** (`Deliverable3/governance-dashboard/`): React 19, TypeScript, Vite 8, styled with Tailwind CSS 4 via `@tailwindcss/vite`. API calls use Vite's dev proxy — requests to `/api/*` are forwarded to `http://localhost:3002`. No API base URL needed in frontend code.
- **Key component**: `Deliverable3/governance-dashboard/src/components/HumanGovernanceModel.tsx` — five sections: Opportunity Matrix, Verification Layer, Risk Matrix, RACI Model, and the Human-in-the-Loop Workflow timeline.

---

## Getting Started

### Prerequisites

Ensure Node.js is installed. On corporate/proxy networks, you may need to configure a CA certificate before running `npm install`.

**Option A — CA certificate file:**
```bash
npm config set cafile "C:\path\to\your-ca-bundle.crt"
```

**Option B — Disable strict SSL (trusted networks only):**
```bash
npm config set strict-ssl false
```

**Option C — Per-session environment variable:**
```bash
export NODE_EXTRA_CA_CERTS="C:\path\to\your-ca-bundle.crt"
```

### Installation & Dev Start

Start the **backend first**, then the frontend in a second terminal.

**Terminal 1 — Backend:**
```bash
cd "Deliverable3/server"
npm install
npm run dev
```

**Terminal 2 — Frontend:**
```bash
cd "Deliverable3/governance-dashboard"
npm install
npm run dev
```

Open `http://localhost:5174` in your browser.

---

## Environment Variables

`Deliverable3/server/.env` (gitignored):
```
PORT=3002
```

---

## Scripts

**Backend (`Deliverable3/server/`):**

| Script | Command | Description |
|---|---|---|
| `dev` | `node --watch index.js` | Dev server with auto-restart |
| `start` | `node index.js` | Production start |

**Frontend (`Deliverable3/governance-dashboard/`):**

| Script | Command | Description |
|---|---|---|
| `dev` | `vite` | Dev server with HMR |
| `build` | `tsc -b && vite build` | Type-check + production build |
| `lint` | `eslint .` | Lint all source files |
| `preview` | `vite preview` | Preview production build locally |

---

## Key Files

| File | Description |
|---|---|
| `Deliverable3/server/index.js` | Express entry point, CORS config, `/api/health` route |
| `Deliverable3/governance-dashboard/vite.config.ts` | Vite config with `/api` proxy to backend and Tailwind plugin |
| `Deliverable3/governance-dashboard/src/components/HumanGovernanceModel.tsx` | Main dashboard: Opportunity Matrix, Verification Layer, Risk Matrix, RACI Model, Workflow |
| `Deliverable3/governance-dashboard/src/App.tsx` | Root React component |

---

## License

See [LICENSE](../LICENSE).
