# Deliverable 1 — AI Innovation Map Dashboard

https://claude.ai/public/artifacts/5a91cf52-9f48-48b2-8e29-fbc21bb31d59

Interactive web dashboard for visualizing AI innovations across organizations, use cases, and maturity stages — designed for clear stakeholder communication and fast exploration of innovation priorities.

> Built for the **WIC × Microsoft AI Innovator Apprenticeship (2026)**

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript 5, Vite |
| Data Visualization | Custom React components + CSS |
| Tooling | Node.js, npm, TypeScript |

---

## Project Structure

```text
Deliverable1/
├── src/
│   ├── components/               # Dashboard and visualization components
│   ├── data/                     # Innovation map dataset / constants
│   ├── App.tsx                   # Root app component
│   ├── main.tsx                  # App entry point
│   └── index.css                 # Global styles
├── public/                       # Static assets
├── index.html
├── package.json
├── tsconfig.json
└── vite.config.ts
```

---

## Features

| Feature | Description |
|---|---|
| **Innovation Map View** | Visual layout of AI initiatives by domain, function, or strategic theme |
| **Category Filtering** | Filter innovations by category, business area, or technology type |
| **Priority/Maturity Signals** | Highlight initiatives by impact, feasibility, and maturity stage |
| **Stakeholder-Ready UX** | Presentation-friendly dashboard with clear labels and intuitive interactions |
| **Extensible Dataset** | Add or update mapped innovations with minimal code changes |

---

## Getting Started

### Prerequisites
- Node.js 18+

### Installation & Run

```bash
cd Deliverable1
npm install
npm run dev
```

Runs on `http://localhost:5173` (or next available Vite port)

---

## Environment Variables

This deliverable currently does not require required environment variables.

If needed later, create:

**`Deliverable1/.env`**
```env
# Example
# VITE_API_URL=http://localhost:4000
```

---

## Scripts

| Script | Command | Description |
|---|---|---|
| `dev` | `vite` | Start development server with HMR |
| `build` | `tsc -b && vite build` | Type-check and build for production |
| `preview` | `vite preview` | Preview production build locally |
| `typecheck` | `tsc -b --noEmit` | Type-check only |

---

## Key Files

| File | Purpose |
|---|---|
| `Deliverable1/src/App.tsx` | Main dashboard composition and layout |
| `Deliverable1/src/components/*` | Reusable visualization and UI components |
| `Deliverable1/src/data/*` | Innovation map source data and metadata |
| `Deliverable1/src/index.css` | Global styling and design tokens |
| `Deliverable1/vite.config.ts` | Vite configuration |

---

## Usage Notes

1. Start the app with `npm run dev`.
2. Use filters/search controls to narrow innovation categories.
3. Review each mapped item’s theme, value, and stage indicators.
4. Update source data in `src/data/` to reflect current innovation portfolio.

---

## Troubleshooting

### Port Already in Use
If `5173` is in use, Vite automatically picks another port. Check terminal output for the active URL.

### Dependency Issues
Delete `node_modules` and lockfile, then reinstall:

```bash
rm -rf node_modules package-lock.json
npm install
```

### Build Errors
Run:

```bash
npm run typecheck
```

Fix reported TypeScript issues, then retry `npm run build`.

---

## Production Build

```bash
cd Deliverable1
npm run build
npm run preview
```

Production assets are emitted to `Deliverable1/dist/`.

---

## License

See [LICENSE](../LICENSE) in the repository root.

---

## Contact & Support

For questions about Deliverable 1, refer to the main project [README](../README.md) or contact project maintainers.
