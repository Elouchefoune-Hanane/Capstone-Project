import AIInnovationMap from './components/aiinnovationmap'

function App() {
  return <AIInnovationMap />
}

export default App
