import { useEffect, useState } from "react";
import { T } from "./theme";
import { DiagramMeta } from "./types";
import { fetchDiagramList } from "./api/client";
import { Header } from "./components/Header";
import { Sidebar } from "./components/Sidebar";
import { LoadingState, ErrorState } from "./components/LoadingState";
import { SystemContext } from "./components/diagrams/SystemContext";
import { ContainerDiagram } from "./components/diagrams/ContainerDiagram";
import { ComponentDiagram } from "./components/diagrams/ComponentDiagram";
import { E2EWorkflow } from "./components/diagrams/E2EWorkflow";
import { SwimlaneDiagram } from "./components/diagrams/SwimlaneDiagram";
import { BPMNDiagram } from "./components/diagrams/BPMNDiagram";
import { DecisionBoundary } from "./components/diagrams/DecisionBoundary";
import { SolutionArchitecture } from "./components/diagrams/SolutionArchitecture";

const DIAGRAM_COMPONENTS: Record<string, () => JSX.Element> = {
  sysctx: SystemContext,
  container: ContainerDiagram,
  component: ComponentDiagram,
  e2e: E2EWorkflow,
  swimlane: SwimlaneDiagram,
  bpmn: BPMNDiagram,
  boundary: DecisionBoundary,
  arch: SolutionArchitecture,
};

export default function App() {
  const [diagrams, setDiagrams] = useState<DiagramMeta[]>([]);
  const [listLoading, setListLoading] = useState(true);
  const [listError, setListError] = useState<string | null>(null);
  const [active, setActive] = useState<string | null>(null);

  useEffect(() => {
    fetchDiagramList()
      .then((list) => {
        setDiagrams(list);
        setActive(list[0]?.id ?? null);
        setListLoading(false);
      })
      .catch((err: Error) => {
        setListError(err.message);
        setListLoading(false);
      });
  }, []);

  if (listLoading) {
    return (
      <div style={{ minHeight: "100vh", background: T.bg, color: T.text }}>
        <LoadingState />
      </div>
    );
  }

  if (listError || !active) {
    return (
      <div style={{ minHeight: "100vh", background: T.bg, color: T.text, padding: 32 }}>
        <ErrorState message={listError ?? "No diagrams available"} />
      </div>
    );
  }

  const D = diagrams.find((d) => d.id === active)!;
  const Comp = DIAGRAM_COMPONENTS[D.id];

  return (
    <div style={{ minHeight: "100vh", background: T.bg, color: T.text, fontFamily: "'DM Sans','Segoe UI',sans-serif" }}>
      <Header />

      <div style={{ display: "flex", height: "calc(100vh - 70px)" }}>
        <Sidebar diagrams={diagrams} activeId={active} onSelect={setActive} />

        <div style={{ flex: 1, overflowY: "auto", padding: "28px 32px" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 24 }}>
            <span style={{ fontSize: 28 }}>{D.icon}</span>
            <div>
              <div style={{ fontSize: 9, letterSpacing: 2.5, color: T.teal, fontWeight: 700 }}>{D.sub}</div>
              <h2 style={{ margin: 0, fontSize: 20, fontWeight: 800 }}>{D.label}</h2>
            </div>
          </div>
          {Comp ? <Comp /> : <ErrorState message={`No component registered for diagram "${D.id}"`} />}
        </div>
      </div>
    </div>
  );
}
