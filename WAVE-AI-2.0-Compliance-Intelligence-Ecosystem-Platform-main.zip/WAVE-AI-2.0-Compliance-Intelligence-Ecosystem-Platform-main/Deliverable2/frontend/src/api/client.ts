import { DiagramMeta } from "../types";

const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:4000";

async function getJSON<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) {
    throw new Error(`Request to ${path} failed with status ${res.status}`);
  }
  return res.json() as Promise<T>;
}

export function fetchDiagramList(): Promise<DiagramMeta[]> {
  return getJSON<DiagramMeta[]>("/api/diagrams");
}

export function fetchDiagramData<T>(id: string): Promise<T> {
  return getJSON<T>(`/api/diagrams/${id}`);
}
