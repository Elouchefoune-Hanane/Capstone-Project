import { useEffect, useState } from "react";
import { fetchDiagramData } from "../api/client";

interface DiagramDataState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

export function useDiagramData<T>(id: string): DiagramDataState<T> {
  const [state, setState] = useState<DiagramDataState<T>>({
    data: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;
    setState({ data: null, loading: true, error: null });

    fetchDiagramData<T>(id)
      .then((data) => {
        if (!cancelled) setState({ data, loading: false, error: null });
      })
      .catch((err: Error) => {
        if (!cancelled) setState({ data: null, loading: false, error: err.message });
      });

    return () => {
      cancelled = true;
    };
  }, [id]);

  return state;
}
