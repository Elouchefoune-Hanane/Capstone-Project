import { T } from "../theme";

export function Header() {
  return (
    <div
      style={{
        padding: "18px 32px",
        borderBottom: `1px solid ${T.border}`,
        background: T.surface,
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
      }}
    >
      <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
        <div
          style={{
            width: 34,
            height: 34,
            borderRadius: 8,
            background: `linear-gradient(135deg,${T.teal},${T.violet})`,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            fontSize: 17,
          }}
        >
          ⚡
        </div>
        <div>
          <div style={{ fontSize: 10, letterSpacing: 3, color: T.teal, fontWeight: 800 }}>
            WAVE AI · CAPSTONE DELIVERABLE SUITE
          </div>
          <div style={{ fontSize: 16, fontWeight: 800, letterSpacing: -0.3 }}>
            Compliance Intelligence Ecosystem — Architecture Diagrams
          </div>
        </div>
      </div>
      <div style={{ fontSize: 10, color: T.muted, textAlign: "right", lineHeight: 1.6 }}>
        WIC × Microsoft AI Innovator Apprenticeship · 2026
        <br />
        <span style={{ color: T.teal }}>8 Diagrams · All Deliverables Covered</span>
      </div>
    </div>
  );
}
