import { useState } from "react";
import { T, colorFor } from "../../theme";
import { ComponentDiagramData } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

function ComponentDiagramView({ data }: { data: ComponentDiagramData }) {
  const [flowId, setFlowId] = useState(data.flows[0]?.id ?? "");
  const active = data.flows.find((f) => f.id === flowId) ?? data.flows[0];
  if (!active) return null;
  const activeColor = colorFor(active.colorKey);

  return (
    <div>
      <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
        {data.flows.map((v) => {
          const color = colorFor(v.colorKey);
          return (
            <button
              key={v.id}
              onClick={() => setFlowId(v.id)}
              style={{
                padding: "7px 16px",
                borderRadius: 8,
                cursor: "pointer",
                fontSize: 11,
                fontWeight: 600,
                transition: "all 0.2s",
                background: flowId === v.id ? `${color}20` : "transparent",
                border: `1px solid ${flowId === v.id ? color + "80" : T.border}`,
                color: flowId === v.id ? color : T.muted,
              }}
            >
              {v.label.split(". ")[0]}
            </button>
          );
        })}
      </div>
      <div style={{ fontSize: 13, fontWeight: 700, color: activeColor, marginBottom: 16 }}>{active.label}</div>
      <div style={{ display: "flex", flexDirection: "column", gap: 0 }}>
        {active.steps.map((s, i) => (
          <div key={i} style={{ display: "flex", gap: 0 }}>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", width: 40 }}>
              <div
                style={{
                  width: 36,
                  height: 36,
                  borderRadius: "50%",
                  background: `${activeColor}18`,
                  border: `1px solid ${activeColor}60`,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  fontSize: 16,
                  flexShrink: 0,
                }}
              >
                {s.icon}
              </div>
              {i < active.steps.length - 1 && (
                <div style={{ width: 1, flex: 1, minHeight: 16, background: `${activeColor}30`, margin: "2px 0" }} />
              )}
            </div>
            <div
              style={{
                marginLeft: 14,
                marginBottom: i < active.steps.length - 1 ? 12 : 0,
                paddingBottom: 12,
                borderBottom: i < active.steps.length - 1 ? `1px solid ${T.border}` : "none",
                flex: 1,
              }}
            >
              <div style={{ fontSize: 13, fontWeight: 700, color: activeColor, marginBottom: 4 }}>{s.label}</div>
              <div style={{ fontSize: 12, color: T.muted, lineHeight: 1.7 }}>{s.desc}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ComponentDiagram() {
  const { data, loading, error } = useDiagramData<ComponentDiagramData>("component");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <ComponentDiagramView data={data} />;
}
