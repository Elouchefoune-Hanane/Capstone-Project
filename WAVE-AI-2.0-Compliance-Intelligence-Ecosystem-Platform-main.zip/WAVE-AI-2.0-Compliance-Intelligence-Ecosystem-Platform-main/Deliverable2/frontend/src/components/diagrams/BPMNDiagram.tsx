import { useState } from "react";
import { T, colorFor } from "../../theme";
import { BPMNDiagramData, BPMNNode, BPMNOwner } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

const OWNER_COLOR: Record<BPMNOwner, string> = { AI: T.teal, HUMAN: T.orange, GOV: T.gold };

function BPMNDiagramView({ data }: { data: BPMNDiagramData }) {
  const [hover, setHover] = useState<string | null>(null);
  const { nodes, edges, branchLabels } = data;

  return (
    <div style={{ overflowX: "auto" }}>
      <svg width={1380} height={340} style={{ display: "block" }}>
        {/* Pool background */}
        <rect x={10} y={10} width={1360} height={310} rx={12} fill={T.card} stroke={T.border} strokeWidth={1} />
        <text
          x={26}
          y={165}
          fill={T.muted}
          fontSize={10}
          fontWeight={700}
          writingMode="vertical-lr"
          textAnchor="middle"
          letterSpacing={2}
        >
          COMPLIANCE PROCESS
        </text>

        {/* Connections */}
        {edges.map(({ from, to }, i) => {
          const f = nodes.find((n) => n.id === from);
          const t = nodes.find((n) => n.id === to);
          if (!f || !t) return null;
          const fx = f.x + (f.shape === "diamond" ? 20 : f.shape === "circle" || f.shape === "circle-end" ? 16 : 55);
          const fy = f.y + (f.shape === "diamond" ? 20 : f.shape === "circle" || f.shape === "circle-end" ? 16 : 18);
          const tx = t.x + (t.shape === "diamond" ? 0 : t.shape === "circle" || t.shape === "circle-end" ? 0 : 0);
          const ty = t.y + (t.shape === "diamond" ? 20 : t.shape === "circle" || t.shape === "circle-end" ? 16 : 18);
          const isDown = fy < ty - 10;
          return (
            <g key={i}>
              {isDown ? (
                <polyline
                  points={`${fx},${fy} ${fx},${ty} ${tx},${ty}`}
                  fill="none"
                  stroke={T.border}
                  strokeWidth={1.5}
                  markerEnd="url(#arrow)"
                />
              ) : (
                <line x1={fx} y1={fy} x2={tx} y2={ty} stroke={T.border} strokeWidth={1.5} markerEnd="url(#arrow)" />
              )}
            </g>
          );
        })}

        <defs>
          <marker id="arrow" markerWidth={8} markerHeight={8} refX={6} refY={3} orient="auto">
            <path d="M0,0 L0,6 L8,3 z" fill={T.muted} />
          </marker>
        </defs>

        {/* Nodes */}
        {nodes.map((n: BPMNNode) => {
          const nodeColor = colorFor(n.colorKey);
          const oc = n.owner ? OWNER_COLOR[n.owner] : nodeColor;

          if (n.shape === "circle" || n.shape === "circle-end") {
            return (
              <g key={n.id} onMouseEnter={() => setHover(n.id)} onMouseLeave={() => setHover(null)}>
                <circle
                  cx={n.x + 16}
                  cy={n.y + 16}
                  r={14}
                  fill={`${nodeColor}18`}
                  stroke={nodeColor}
                  strokeWidth={n.shape === "circle-end" ? 3 : 1.5}
                />
                <text x={n.x + 16} y={n.y + 38} textAnchor="middle" fill={nodeColor} fontSize={8} fontWeight={700}>
                  {n.label.split("\n").map((l, li) => (
                    <tspan key={li} x={n.x + 16} dy={li === 0 ? 0 : 10}>
                      {l}
                    </tspan>
                  ))}
                </text>
              </g>
            );
          }

          if (n.shape === "diamond") {
            return (
              <g key={n.id} onMouseEnter={() => setHover(n.id)} onMouseLeave={() => setHover(null)}>
                <polygon
                  points={`${n.x + 20},${n.y} ${n.x + 40},${n.y + 20} ${n.x + 20},${n.y + 40} ${n.x},${n.y + 20}`}
                  fill={`${nodeColor}18`}
                  stroke={nodeColor}
                  strokeWidth={1.5}
                />
                <text x={n.x + 20} y={n.y + 56} textAnchor="middle" fill={nodeColor} fontSize={8} fontWeight={700}>
                  {n.label.split("\n").map((l, li) => (
                    <tspan key={li} x={n.x + 20} dy={li === 0 ? 0 : 10}>
                      {l}
                    </tspan>
                  ))}
                </text>
              </g>
            );
          }

          return (
            <g key={n.id} onMouseEnter={() => setHover(n.id)} onMouseLeave={() => setHover(null)}>
              <rect
                x={n.x}
                y={n.y}
                width={100}
                height={36}
                rx={6}
                fill={hover === n.id ? `${oc}28` : `${oc}14`}
                stroke={hover === n.id ? oc : `${oc}60`}
                strokeWidth={1.5}
              />
              {n.owner && <rect x={n.x} y={n.y} width={8} height={36} rx={3} fill={oc} opacity={0.7} />}
              <text x={n.x + 54} y={n.y + 13} textAnchor="middle" fill={oc} fontSize={8.5} fontWeight={700}>
                {n.label.split("\n").map((l, li) => (
                  <tspan key={li} x={n.x + 54} dy={li === 0 ? 0 : 11}>
                    {l}
                  </tspan>
                ))}
              </text>
            </g>
          );
        })}

        {/* Labels on branches */}
        {branchLabels.map((b, i) => (
          <text key={i} x={b.x} y={b.y} fill={T.muted} fontSize={8}>
            {b.label}
          </text>
        ))}
      </svg>

      {/* Legend */}
      <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
        {(
          [
            ["AI Automated", T.teal],
            ["Human Authority", T.orange],
            ["Governance", T.gold],
            ["Gateway", T.gold],
          ] as [string, string][]
        ).map(([l, c]) => (
          <div key={l} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 8, height: 8, background: c, borderRadius: 2 }} />
            <span style={{ fontSize: 10, color: T.muted }}>{l}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function BPMNDiagram() {
  const { data, loading, error } = useDiagramData<BPMNDiagramData>("bpmn");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <BPMNDiagramView data={data} />;
}
