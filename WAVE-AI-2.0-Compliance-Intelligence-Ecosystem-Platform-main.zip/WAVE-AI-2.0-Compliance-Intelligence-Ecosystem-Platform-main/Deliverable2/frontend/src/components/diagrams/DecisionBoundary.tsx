import { useState } from "react";
import { T, colorFor } from "../../theme";
import { DecisionBoundaryData } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

function DecisionBoundaryView({ data }: { data: DecisionBoundaryData }) {
  const [sel, setSel] = useState<string | null>(null);
  const { zones, items } = data;

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 16, marginBottom: 20 }}>
        {zones.map((z) => {
          const color = colorFor(z.colorKey);
          return (
            <div
              key={z.id}
              style={{
                padding: "16px",
                borderRadius: 12,
                background: `${color}10`,
                border: `1px solid ${color}40`,
              }}
            >
              <div
                style={{
                  fontSize: 11,
                  fontWeight: 800,
                  color,
                  letterSpacing: 1,
                  marginBottom: 6,
                  textTransform: "uppercase",
                }}
              >
                {z.label}
              </div>
              <div style={{ fontSize: 11, color: T.muted, lineHeight: 1.6 }}>{z.desc}</div>
              <div style={{ marginTop: 10, fontSize: 10, color, fontWeight: 700 }}>
                {items.filter((i) => i.zone === z.id).length} capabilities
              </div>
            </div>
          );
        })}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr 1fr", gap: 8 }}>
        {zones.map((z) => (
          <div key={z.id} style={{ display: "flex", flexDirection: "column", gap: 6 }}>
            {items
              .filter((i) => i.zone === z.id)
              .map((item, idx) => {
                const key = `${z.id}-${idx}`;
                const color = colorFor(item.colorKey);
                const isSel = sel === key;
                return (
                  <div
                    key={idx}
                    onClick={() => setSel(isSel ? null : key)}
                    style={{
                      padding: "10px 12px",
                      borderRadius: 10,
                      cursor: "pointer",
                      background: isSel ? `${color}18` : T.card,
                      border: `1px solid ${isSel ? color + "60" : T.border}`,
                      transition: "all 0.2s",
                    }}
                  >
                    <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                      <div
                        style={{
                          width: 6,
                          height: 6,
                          borderRadius: "50%",
                          background: color,
                          marginTop: 4,
                          flexShrink: 0,
                        }}
                      />
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: T.text }}>{item.label}</div>
                        {isSel && (
                          <div style={{ fontSize: 11, color: T.muted, marginTop: 6, lineHeight: 1.6 }}>
                            {item.detail}
                          </div>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        ))}
      </div>
      <div style={{ marginTop: 10, fontSize: 10, color: T.muted, textAlign: "center" }}>
        CLICK ANY ITEM TO SEE DECISION RATIONALE
      </div>
    </div>
  );
}

export function DecisionBoundary() {
  const { data, loading, error } = useDiagramData<DecisionBoundaryData>("boundary");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <DecisionBoundaryView data={data} />;
}
