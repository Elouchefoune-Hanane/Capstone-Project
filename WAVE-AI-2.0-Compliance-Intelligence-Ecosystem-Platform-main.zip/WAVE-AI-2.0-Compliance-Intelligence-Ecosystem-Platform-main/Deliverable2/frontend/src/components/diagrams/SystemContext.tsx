import { useState } from "react";
import { T, colorFor } from "../../theme";
import { SystemContextData } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

function SystemContextView({ data }: { data: SystemContextData }) {
  const [hover, setHover] = useState<string | null>(null);
  const { core, actors, flows } = data;

  const renderActor = (a: SystemContextData["actors"][number]) => {
    const color = colorFor(a.colorKey);
    return (
      <div
        key={a.id}
        onMouseEnter={() => setHover(a.id)}
        onMouseLeave={() => setHover(null)}
        style={{
          position: "absolute",
          [a.side]: 0,
          top: a.top,
          width: 210,
          background: hover === a.id ? `${color}14` : T.card,
          border: `1px solid ${hover === a.id ? color + "60" : T.border}`,
          borderRadius: 14,
          padding: "14px 16px",
          cursor: "default",
          transition: "all 0.2s",
        }}
      >
        <div style={{ fontSize: 12, fontWeight: 700, color, marginBottom: 4, whiteSpace: "pre-line" }}>
          {a.label}
        </div>
        <div style={{ fontSize: 10, color: T.muted, lineHeight: 1.6, whiteSpace: "pre-line" }}>{a.sub}</div>
      </div>
    );
  };

  return (
    <div style={{ position: "relative", width: "100%", minHeight: 780 }}>
      {/* CIE Core Box */}
      <div
        style={{
          position: "absolute",
          left: "50%",
          top: "50%",
          transform: "translate(-50%,-50%)",
          width: 260,
          borderRadius: 20,
          background: `linear-gradient(135deg,${T.teal}18,${T.violet}18)`,
          border: `2px solid ${T.teal}60`,
          padding: "28px 24px",
          textAlign: "center",
          zIndex: 2,
          boxShadow: `0 0 60px ${T.teal}20`,
        }}
      >
        <div style={{ fontSize: 28, marginBottom: 8 }}>⚡</div>
        <div style={{ fontSize: 11, letterSpacing: 3, color: T.teal, fontWeight: 800, marginBottom: 6 }}>
          PRIMARY SYSTEM
        </div>
        <div style={{ fontSize: 16, fontWeight: 800, color: T.text, marginBottom: 8, lineHeight: 1.3, whiteSpace: "pre-line" }}>
          {core.label}
        </div>
        <div style={{ fontSize: 11, color: T.muted, lineHeight: 1.7, whiteSpace: "pre-line" }}>{core.sub}</div>
        <div style={{ marginTop: 14, display: "flex", flexWrap: "wrap", gap: 4, justifyContent: "center" }}>
          {core.tags.map((l) => (
            <span
              key={l}
              style={{
                fontSize: 8,
                color: T.teal,
                border: `1px solid ${T.teal}30`,
                borderRadius: 10,
                padding: "2px 7px",
                letterSpacing: 1,
              }}
            >
              {l}
            </span>
          ))}
        </div>
      </div>

      {actors.filter((a) => a.side === "left").map(renderActor)}
      {actors.filter((a) => a.side === "right").map(renderActor)}

      {/* Flow labels */}
      {flows.map((f) => {
        const source = actors.find((a) => a.id === f.from);
        const isLeft = source?.side === "left";
        const color = colorFor(f.colorKey);
        return (
          <div
            key={f.from}
            style={{
              position: "absolute",
              left: isLeft ? 218 : undefined,
              right: isLeft ? undefined : 218,
              top: (source?.top ?? 0) + 30,
              width: 120,
              fontSize: 9,
              color,
              lineHeight: 1.5,
              whiteSpace: "pre-line",
              textAlign: isLeft ? "left" : "right",
              fontStyle: "italic",
            }}
          >
            ↔ {f.label}
          </div>
        );
      })}

      {/* Legend */}
      <div
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          display: "flex",
          gap: 16,
          justifyContent: "center",
          fontSize: 10,
          color: T.muted,
        }}
      >
        <span style={{ color: T.blue }}>◆ Source Systems</span>
        <span style={{ color: T.teal }}>◆ Internal Users</span>
        <span style={{ color: T.orange }}>◆ Regulators</span>
        <span style={{ color: T.violet }}>◆ Governance Bodies</span>
      </div>
    </div>
  );
}

export function SystemContext() {
  const { data, loading, error } = useDiagramData<SystemContextData>("sysctx");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <SystemContextView data={data} />;
}
