import { T, colorFor } from "../../theme";
import { SwimlaneDiagramData } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

const COL_W = 86;

function SwimlaneDiagramView({ data }: { data: SwimlaneDiagramData }) {
  const { lanes, cols } = data;

  return (
    <div style={{ overflowX: "auto" }}>
      <div style={{ minWidth: cols * COL_W + 160 }}>
        {/* Column headers */}
        <div style={{ display: "flex", marginLeft: 160, marginBottom: 8 }}>
          {Array.from({ length: cols }, (_, i) => (
            <div
              key={i}
              style={{
                width: COL_W,
                textAlign: "center",
                fontSize: 9,
                color: T.muted,
                letterSpacing: 1,
                fontWeight: 700,
              }}
            >
              STEP {i + 1}
            </div>
          ))}
        </div>

        {/* Lanes */}
        {lanes.map((lane) => {
          const color = colorFor(lane.colorKey);
          return (
            <div key={lane.id} style={{ display: "flex", marginBottom: 8, alignItems: "stretch" }}>
              {/* Lane label */}
              <div
                style={{
                  width: 152,
                  flexShrink: 0,
                  padding: "0 12px",
                  background: `${color}10`,
                  border: `1px solid ${color}30`,
                  borderRadius: "10px 0 0 10px",
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <span style={{ fontSize: 11, fontWeight: 700, color, lineHeight: 1.3 }}>{lane.label}</span>
              </div>

              {/* Cells */}
              <div
                style={{
                  display: "grid",
                  gridTemplateColumns: `repeat(${cols},${COL_W}px)`,
                  background: T.card,
                  border: `1px solid ${T.border}`,
                  borderLeft: "none",
                  borderRadius: "0 10px 10px 0",
                  position: "relative",
                  minHeight: 64,
                }}
              >
                {/* Grid lines */}
                {Array.from({ length: cols - 1 }, (_, i) => (
                  <div
                    key={i}
                    style={{
                      position: "absolute",
                      left: (i + 1) * COL_W,
                      top: 0,
                      bottom: 0,
                      width: 1,
                      background: T.border,
                    }}
                  />
                ))}

                {/* Steps */}
                {lane.steps.map((s, si) => (
                  <div
                    key={si}
                    style={{
                      position: "absolute",
                      left: s.col * COL_W + 4,
                      top: 8,
                      width: COL_W - 8,
                      background: `${color}18`,
                      border: `1px solid ${color}50`,
                      borderRadius: 8,
                      padding: "6px 8px",
                      textAlign: "center",
                    }}
                  >
                    <div style={{ fontSize: 10, fontWeight: 700, color, lineHeight: 1.3 }}>{s.label}</div>
                    <div style={{ fontSize: 9, color: T.muted, marginTop: 2 }}>{s.sub}</div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}

        {/* Flow arrow */}
        <div style={{ marginLeft: 160, display: "flex", alignItems: "center", marginTop: 8 }}>
          <div
            style={{
              flex: 1,
              height: 2,
              background: `linear-gradient(90deg,${T.teal},${T.violet},${T.orange})`,
              borderRadius: 2,
            }}
          />
          <div style={{ fontSize: 10, color: T.muted, marginLeft: 8 }}>TRANSACTION FLOW →</div>
        </div>
      </div>
    </div>
  );
}

export function SwimlaneDiagram() {
  const { data, loading, error } = useDiagramData<SwimlaneDiagramData>("swimlane");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <SwimlaneDiagramView data={data} />;
}
