import { useState } from "react";
import { T, colorFor } from "../../theme";
import { E2EWorkflowData, OwnerKey } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";
import { Pill } from "../Pill";

const OWNER_COLORS: Record<OwnerKey, string> = {
  AI: T.teal,
  "AI+H": T.violet,
  HUMAN: T.orange,
  GOV: T.gold,
};

const OWNER_LABELS: Record<OwnerKey, string> = {
  AI: "AI Automated",
  "AI+H": "AI Assists / Human Decides",
  HUMAN: "Human Authority",
  GOV: "Governance Layer",
};

function E2EWorkflowView({ data }: { data: E2EWorkflowData }) {
  const [active, setActive] = useState<number | null>(null);

  return (
    <div>
      {/* Legend */}
      <div style={{ display: "flex", gap: 12, marginBottom: 20, flexWrap: "wrap" }}>
        {(Object.entries(OWNER_LABELS) as [OwnerKey, string][]).map(([k, v]) => (
          <div key={k} style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <div style={{ width: 10, height: 10, borderRadius: "50%", background: OWNER_COLORS[k] }} />
            <span style={{ fontSize: 10, color: T.muted }}>{v}</span>
          </div>
        ))}
      </div>

      {/* Steps */}
      <div style={{ display: "flex", flexDirection: "column", gap: 6 }}>
        {data.steps.map((s, i) => {
          const color = colorFor(s.colorKey);
          return (
            <div key={s.id}>
              <div
                onClick={() => setActive(active === s.id ? null : s.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 12,
                  padding: "12px 16px",
                  borderRadius: 10,
                  cursor: "pointer",
                  transition: "all 0.2s",
                  background: active === s.id ? `${color}14` : T.card,
                  border: `1px solid ${active === s.id ? color + "60" : T.border}`,
                }}
              >
                <div
                  style={{
                    width: 36,
                    height: 36,
                    borderRadius: 10,
                    background: `${color}18`,
                    border: `1px solid ${color}40`,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 16,
                    flexShrink: 0,
                  }}
                >
                  {s.icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 9, letterSpacing: 2, color: T.muted, fontWeight: 700 }}>{s.phase}</div>
                  <div style={{ fontSize: 13, fontWeight: 700, color: T.text }}>{s.label}</div>
                </div>
                <Pill color={OWNER_COLORS[s.owner]} label={OWNER_LABELS[s.owner]} />
                <div
                  style={{
                    fontSize: 14,
                    color: T.muted,
                    transition: "transform 0.2s",
                    transform: active === s.id ? "rotate(90deg)" : "none",
                  }}
                >
                  ›
                </div>
              </div>
              {active === s.id && (
                <div
                  style={{
                    margin: "4px 0 4px 48px",
                    padding: "12px 16px",
                    borderRadius: 8,
                    background: `${color}08`,
                    border: `1px solid ${color}30`,
                    fontSize: 12,
                    color: T.muted,
                    lineHeight: 1.7,
                  }}
                >
                  {s.detail}
                </div>
              )}
              {i < data.steps.length - 1 && (
                <div style={{ display: "flex", justifyContent: "center", margin: "2px 0" }}>
                  <div style={{ width: 1, height: 8, background: `${color}40` }} />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export function E2EWorkflow() {
  const { data, loading, error } = useDiagramData<E2EWorkflowData>("e2e");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <E2EWorkflowView data={data} />;
}
