import { T, colorFor } from "../../theme";
import { SolutionArchitectureData } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

function SolutionArchitectureView({ data }: { data: SolutionArchitectureData }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {data.layers.map((layer) => {
        const color = colorFor(layer.colorKey);
        return (
          <div key={layer.id}>
            <div
              style={{
                fontSize: 9,
                letterSpacing: 2.5,
                fontWeight: 800,
                color,
                textTransform: "uppercase",
                marginBottom: 6,
                paddingLeft: 4,
              }}
            >
              {layer.label}
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 8 }}>
              {layer.items.map((item, i) => (
                <div
                  key={i}
                  style={{
                    padding: "12px 14px",
                    borderRadius: 10,
                    background: T.card,
                    border: `1px solid ${T.border}`,
                    transition: "border-color 0.2s",
                  }}
                >
                  <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                    <span style={{ fontSize: 18, flexShrink: 0 }}>{item.icon}</span>
                    <div>
                      <div style={{ fontSize: 11, fontWeight: 700, color, marginBottom: 3 }}>{item.label}</div>
                      <div style={{ fontSize: 10, color: T.muted, lineHeight: 1.5 }}>{item.sub}</div>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );
      })}
    </div>
  );
}

export function SolutionArchitecture() {
  const { data, loading, error } = useDiagramData<SolutionArchitectureData>("arch");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <SolutionArchitectureView data={data} />;
}
