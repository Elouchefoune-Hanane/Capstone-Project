import { useState } from "react";
import { T, colorFor } from "../../theme";
import { ContainerDiagramData, ContainerNode } from "../../types";
import { useDiagramData } from "../../hooks/useDiagramData";
import { LoadingState, ErrorState } from "../LoadingState";

function ContainerDiagramView({ data }: { data: ContainerDiagramData }) {
  const [sel, setSel] = useState<string | null>(null);
  const { containers } = data;

  const grid: ContainerNode[][] = [[], [], [], [], []];
  containers.forEach((c) => {
    if (!grid[c.row]) grid[c.row] = [];
    grid[c.row][c.col] = c;
  });
  const selC = containers.find((c) => c.id === sel);
  const feNode = containers.find((c) => c.id === "fe");

  return (
    <div>
      <div style={{ display: "grid", gridTemplateRows: "repeat(5,auto)", gap: 10 }}>
        {grid.map((row, ri) => (
          <div
            key={ri}
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(3,1fr)",
              gap: 10,
              justifyContent: ri === 0 ? "center" : "stretch",
            }}
          >
            {(ri === 0 ? [undefined, feNode, undefined] : row).map((c, ci) => {
              if (!c) return <div key={ci} />;
              const color = colorFor(c.colorKey);
              return (
                <div
                  key={c.id}
                  onClick={() => setSel(sel === c.id ? null : c.id)}
                  style={{
                    background: sel === c.id ? `${color}18` : T.card,
                    border: `1px solid ${sel === c.id ? color + "80" : T.border}`,
                    borderRadius: 12,
                    padding: "14px 16px",
                    cursor: "pointer",
                    transition: "all 0.2s",
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 6 }}>
                    <span style={{ fontSize: 18 }}>{c.icon}</span>
                    <div>
                      <div style={{ fontSize: 12, fontWeight: 700, color }}>{c.label}</div>
                      <div style={{ fontSize: 10, color: T.muted }}>{c.tech}</div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        ))}
      </div>
      {selC && (
        <div
          style={{
            marginTop: 16,
            padding: "16px 20px",
            borderRadius: 12,
            background: `${colorFor(selC.colorKey)}10`,
            border: `1px solid ${colorFor(selC.colorKey)}40`,
          }}
        >
          <div style={{ fontSize: 13, fontWeight: 700, color: colorFor(selC.colorKey), marginBottom: 6 }}>
            {selC.icon} {selC.label} — {selC.tech}
          </div>
          <div style={{ fontSize: 12, color: T.text, lineHeight: 1.7 }}>{selC.desc}</div>
        </div>
      )}
      <div style={{ marginTop: 10, fontSize: 10, color: T.muted, textAlign: "center" }}>
        CLICK ANY CONTAINER FOR DETAILS
      </div>
    </div>
  );
}

export function ContainerDiagram() {
  const { data, loading, error } = useDiagramData<ContainerDiagramData>("container");
  if (loading) return <LoadingState />;
  if (error) return <ErrorState message={error} />;
  if (!data) return null;
  return <ContainerDiagramView data={data} />;
}
