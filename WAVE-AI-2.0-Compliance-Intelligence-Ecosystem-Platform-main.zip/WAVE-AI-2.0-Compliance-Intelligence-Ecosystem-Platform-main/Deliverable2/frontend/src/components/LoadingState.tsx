import { T } from "../theme";

export function LoadingState() {
  return (
    <div style={{ padding: "60px 0", textAlign: "center", color: T.muted, fontSize: 12 }}>
      Loading diagram data…
    </div>
  );
}

export function ErrorState({ message }: { message: string }) {
  return (
    <div
      style={{
        padding: "16px 20px",
        borderRadius: 12,
        background: `${T.red}10`,
        border: `1px solid ${T.red}40`,
        color: T.red,
        fontSize: 12,
      }}
    >
      Failed to load diagram data: {message}
    </div>
  );
}
