import { T } from "../theme";
import { DiagramMeta } from "../types";

const DELIVERABLES = [
  "D1 Innovation Map",
  "D2 Workflow Architecture",
  "D3 Governance Model",
  "D4 Demo Architecture",
  "D5 Prompt Library",
];

interface SidebarProps {
  diagrams: DiagramMeta[];
  activeId: string;
  onSelect: (id: string) => void;
}

export function Sidebar({ diagrams, activeId, onSelect }: SidebarProps) {
  return (
    <div
      style={{
        width: 200,
        flexShrink: 0,
        borderRight: `1px solid ${T.border}`,
        background: T.surface,
        padding: "16px 12px",
        overflowY: "auto",
      }}
    >
      <div style={{ fontSize: 9, letterSpacing: 2, color: T.muted, fontWeight: 700, marginBottom: 12, paddingLeft: 4 }}>
        DIAGRAMS
      </div>
      {diagrams.map((d) => {
        const active = activeId === d.id;
        return (
          <button
            key={d.id}
            onClick={() => onSelect(d.id)}
            style={{
              display: "flex",
              alignItems: "center",
              gap: 10,
              width: "100%",
              padding: "9px 10px",
              borderRadius: 8,
              marginBottom: 4,
              background: active ? `${T.teal}14` : "transparent",
              border: `1px solid ${active ? T.teal + "50" : "transparent"}`,
              color: active ? T.teal : T.muted,
              cursor: "pointer",
              textAlign: "left",
              transition: "all 0.15s",
            }}
          >
            <span style={{ fontSize: 16 }}>{d.icon}</span>
            <div>
              <div style={{ fontSize: 11, fontWeight: 700, color: active ? T.teal : T.text }}>{d.label}</div>
              <div style={{ fontSize: 9, color: T.muted }}>{d.sub}</div>
            </div>
          </button>
        );
      })}

      <div
        style={{
          marginTop: 20,
          padding: "12px",
          borderRadius: 10,
          background: `${T.teal}08`,
          border: `1px solid ${T.teal}20`,
        }}
      >
        <div style={{ fontSize: 9, color: T.teal, fontWeight: 700, letterSpacing: 1, marginBottom: 6 }}>
          DELIVERABLES COVERED
        </div>
        {DELIVERABLES.map((d) => (
          <div key={d} style={{ fontSize: 9, color: T.muted, marginBottom: 3 }}>
            ✓ {d}
          </div>
        ))}
      </div>
    </div>
  );
}
