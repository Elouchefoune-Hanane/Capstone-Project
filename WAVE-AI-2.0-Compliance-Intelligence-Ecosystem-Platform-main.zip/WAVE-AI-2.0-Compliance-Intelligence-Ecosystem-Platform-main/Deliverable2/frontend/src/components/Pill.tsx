interface PillProps {
  color: string;
  label: string;
}

export function Pill({ color, label }: PillProps) {
  return (
    <span
      style={{
        fontSize: 10,
        letterSpacing: 2,
        fontWeight: 700,
        textTransform: "uppercase",
        padding: "3px 10px",
        borderRadius: 20,
        color,
        border: `1px solid ${color}40`,
        background: `${color}12`,
      }}
    >
      {label}
    </span>
  );
}
