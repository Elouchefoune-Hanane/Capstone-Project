import { ColorKey } from "./types";

// ─── DESIGN TOKENS ────────────────────────────────────────────────────────────
export const T = {
  bg: "#06080F",
  surface: "#0D1117",
  card: "#111827",
  border: "rgba(255,255,255,0.07)",
  teal: "#00E5C8",
  violet: "#A78BFA",
  orange: "#F97316",
  gold: "#FACC15",
  red: "#F43F5E",
  blue: "#38BDF8",
  text: "#E2E8F0",
  muted: "#64748B",
  dim: "#1E293B",
} as const;

const COLOR_MAP: Record<ColorKey, string> = {
  teal: T.teal,
  violet: T.violet,
  orange: T.orange,
  gold: T.gold,
  red: T.red,
  blue: T.blue,
  muted: T.muted,
};

export function colorFor(key: ColorKey): string {
  return COLOR_MAP[key];
}
