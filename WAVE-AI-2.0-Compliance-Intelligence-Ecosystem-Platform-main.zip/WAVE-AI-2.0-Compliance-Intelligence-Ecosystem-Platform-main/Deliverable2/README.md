# Deliverable 2 — Compliance Intelligence Ecosystem (CIE) Architecture Dashboard

https://claude.ai/public/artifacts/3251d617-7cf7-40c4-9889-a7bc71c67d33

> Multi-perspective system architecture visualization tool for the **WIC × Microsoft AI Innovator Apprenticeship (2026)**

Interactive architecture diagram viewer supporting eight complementary system views — from high-level system context through detailed BPMN workflows — enabling stakeholders to understand compliance systems at multiple levels of abstraction.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript 5, Vite 7 |
| Backend | Node.js (ESM), Express 4, TypeScript 5 |
| Dev tooling | tsx, TypeScript compiler, Vite |

---

## Project Structure

```
Deliverable2/
├── backend/                         # Express.js REST API
│   ├── src/
│   │   ├── index.ts                 # Server entry point
│   │   ├── types.ts                 # Type definitions
│   │   ├── routes/
│   │   │   └── diagrams.ts          # /api/diagrams routes
│   │   └── data/
│   │       ├── index.ts             # Data aggregation
│   │       ├── systemContext.ts     # System Context diagram
│   │       ├── containers.ts        # Container diagram
│   │       ├── componentFlows.ts    # Component diagram
│   │       ├── e2eWorkflow.ts       # End-to-end workflow
│   │       ├── swimlane.ts          # Swimlane diagram
│   │       ├── bpmn.ts              # BPMN workflow
│   │       ├── decisionBoundary.ts  # Decision boundary
│   │       └── solutionArchitecture.ts # Solution architecture
│   ├── package.json
│   └── tsconfig.json
│
└── frontend/                         # React + Vite frontend
    ├── src/
    │   ├── App.tsx                  # Root component
    │   ├── theme.ts                 # Color & style theme
    │   ├── types.ts                 # Frontend types
    │   ├── api/
    │   │   └── client.ts            # API client
    │   ├── hooks/
    │   │   └── useDiagramData.ts    # Diagram data hook
    │   ├── components/
    │   │   ├── Header.tsx           # Top navigation
    │   │   ├── Sidebar.tsx          # Diagram list navigator
    │   │   ├── Pill.tsx             # UI component
    │   │   ├── LoadingState.tsx     # Loading & error states
    │   │   └── diagrams/            # Diagram renderers
    │   │       ├── SystemContext.tsx
    │   │       ├── ContainerDiagram.tsx
    │   │       ├── ComponentDiagram.tsx
    │   │       ├── E2EWorkflow.tsx
    │   │       ├── SwimlaneDiagram.tsx
    │   │       ├── BPMNDiagram.tsx
    │   │       ├── DecisionBoundary.tsx
    │   │       └── SolutionArchitecture.tsx
    │   └── index.css                # Global styles
    ├── public/                      # Static assets
    ├── vite.config.ts               # Vite configuration
    ├── package.json
    ├── index.html
    └── tsconfig.json
```

---

## Architecture

- **Backend** (`Deliverable2/backend/`): TypeScript Express server running on port `4000`. Exposes `/api/diagrams` endpoints serving pre-defined architecture diagram data. CORS enabled for frontend development.
- **Frontend** (`Deliverable2/frontend/`): React 18 + Vite SPA with client-side routing. Fetches diagram metadata and data from backend API. Sidebar navigation allows users to switch between eight diagram views. Default dev port: `5173`.
- **Data Layer**: Backend stores diagram structures (nodes, edges, labels) as TypeScript objects, organized by diagram type. Data served as JSON via REST API.

### Diagram Types

1. **System Context** — High-level system interactions with external entities
2. **Container Diagram** — Major containers/deployable units and communication patterns
3. **Component Diagram** — Components within containers and their dependencies
4. **E2E Workflow** — End-to-end business process flow
5. **Swimlane Diagram** — Cross-functional process flows with actor lanes
6. **BPMN Diagram** — Business Process Model and Notation workflow
7. **Decision Boundary** — Architectural decision boundaries and responsibility zones
8. **Solution Architecture** — Overall solution topology and technology mapping

---

## Getting Started

### Prerequisites

Ensure Node.js (v18+) is installed. On corporate/proxy networks, configure npm to use your organization's CA certificate:

**Option A — CA certificate file:**
```bash
npm config set cafile "C:\path\to\your-ca-bundle.crt"
```

**Option B — Disable strict SSL (trusted networks only):**
```bash
npm config set strict-ssl false
```

**Option C — Per-session environment variable:**
```bash
export NODE_EXTRA_CA_CERTS="C:\path\to\your-ca-bundle.crt"
```

### Installation & Dev Start

Start the **backend first**, then the frontend in separate terminals.

**Terminal 1 — Backend:**
```bash
cd "Deliverable2/backend"
npm install
npm run dev
```

The backend will be available at `http://localhost:4000` with health check at `/api/health`.

**Terminal 2 — Frontend:**
```bash
cd "Deliverable2/frontend"
npm install
npm run dev
```

Open `http://localhost:5173` in your browser.

---

## Environment Variables

**Backend** (`Deliverable2/backend/.env`, optional):
```
PORT=4000
```

If `PORT` is not set, defaults to `4000`.

**Frontend**: No environment variables required for development. The Vite dev server automatically proxies API calls to the backend during development (see `vite.config.ts`).

---

## Scripts

### Backend (`Deliverable2/backend/`)

| Script | Command | Description |
|---|---|---|
| `dev` | `tsx watch src/index.ts` | Dev server with auto-restart on file changes |
| `build` | `tsc -p tsconfig.json` | Compile TypeScript to JavaScript |
| `start` | `node dist/index.js` | Production start (requires build first) |
| `typecheck` | `tsc --noEmit` | Type-check without emitting files |

### Frontend (`Deliverable2/frontend/`)

| Script | Command | Description |
|---|---|---|
| `dev` | `vite` | Dev server with HMR |
| `build` | `tsc -b && vite build` | Type-check + production build |
| `preview` | `vite preview` | Preview production build locally |
| `typecheck` | `tsc -b --noEmit` | Type-check without emitting files |

---

## Key Files

| File | Purpose |
|---|---|
| `Deliverable2/backend/src/index.ts` | Express server initialization, middleware, routes setup |
| `Deliverable2/backend/src/routes/diagrams.ts` | REST endpoints for `/api/diagrams/*` |
| `Deliverable2/backend/src/data/` | Pre-defined diagram structures organized by type |
| `Deliverable2/frontend/src/App.tsx` | Main React component, diagram routing, sidebar navigation |
| `Deliverable2/frontend/src/api/client.ts` | API client for fetching diagram data |
| `Deliverable2/frontend/src/theme.ts` | Centralized color palette and typography theme |
| `Deliverable2/frontend/src/components/diagrams/` | Diagram renderer components (one per view type) |
| `Deliverable2/frontend/vite.config.ts` | Vite dev server proxy configuration |

---

## API Endpoints

### Health Check
```
GET /api/health
```
Returns `{ status: "ok" }` if server is running.

### List All Diagrams
```
GET /api/diagrams
```
Returns array of diagram metadata objects:
```json
[
  {
    "id": "sysctx",
    "name": "System Context",
    "description": "High-level system interactions"
  },
  ...
]
```

### Get Diagram Data
```
GET /api/diagrams/:id
```
Returns full diagram structure (nodes, edges, layout info) for the specified diagram type.

---

## Development Workflow

1. **Backend changes**: Modify files in `Deliverable2/backend/src/`. `tsx watch` will auto-restart the server.
2. **Frontend changes**: Modify files in `Deliverable2/frontend/src/`. Vite HMR will update the browser automatically.
3. **Type checking**: Run `npm run typecheck` in either directory to validate TypeScript without building.
4. **Adding a new diagram**:
   - Create a new data file in `backend/src/data/` (e.g., `newDiagram.ts`)
   - Export diagram metadata and structure
   - Add route handler in `backend/src/routes/diagrams.ts`
   - Create renderer component in `frontend/src/components/diagrams/NewDiagram.tsx`
   - Register component in `App.tsx` DIAGRAM_COMPONENTS map

---

## Troubleshooting

### Port Already in Use
If port 4000 (backend) or 5173 (frontend) is already in use:
- **Backend**: Set `PORT` environment variable (e.g., `PORT=4001 npm run dev`)
- **Frontend**: Vite will auto-select an available port; check console output

### API Connection Errors
Verify backend is running and CORS is enabled. Check backend console for error messages. Ensure `/api` requests in browser DevTools show successful responses from `http://localhost:4000`.

### Module Not Found
Run `npm install` in both `backend/` and `frontend/` directories. Clear `node_modules` and reinstall if issues persist.

---

## Production Build

### Backend
```bash
cd Deliverable2/backend
npm run build
npm start
```

### Frontend
```bash
cd Deliverable2/frontend
npm run build
npm run preview  # Test production build locally
```

Production builds output to `frontend/dist/` and `backend/dist/`. Deploy as needed for your hosting environment.

---

## License

See [LICENSE](../LICENSE) in the repository root.

---

## Contact & Support

For questions or issues with Deliverable 2, refer to the main project [README](../README.md) or contact the project maintainers.
