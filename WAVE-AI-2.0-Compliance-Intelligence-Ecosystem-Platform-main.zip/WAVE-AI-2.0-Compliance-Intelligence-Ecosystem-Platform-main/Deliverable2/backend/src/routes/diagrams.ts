import { Router } from "express";
import { DIAGRAM_META, DIAGRAM_DATA } from "../data";

export const diagramsRouter = Router();

// GET /api/diagrams — list of all diagram metadata (id, label, icon, sub)
diagramsRouter.get("/", (_req, res) => {
  res.json(DIAGRAM_META);
});

// GET /api/diagrams/:id — full data payload for one diagram
diagramsRouter.get("/:id", (req, res) => {
  const { id } = req.params;
  const data = DIAGRAM_DATA[id];

  if (!data) {
    return res.status(404).json({ error: `Unknown diagram id: ${id}` });
  }

  res.json(data);
});
