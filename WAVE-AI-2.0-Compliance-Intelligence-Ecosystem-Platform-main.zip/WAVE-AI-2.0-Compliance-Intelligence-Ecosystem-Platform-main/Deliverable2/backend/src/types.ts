// ─── SHARED TYPES ──────────────────────────────────────────────────────────
// Colors are referenced by semantic key, not hex — the frontend owns the
// actual palette (design tokens) and maps these keys to colors.
export type ColorKey =
  | "teal"
  | "violet"
  | "orange"
  | "gold"
  | "red"
  | "blue"
  | "muted";

export type OwnerKey = "AI" | "AI+H" | "HUMAN" | "GOV";

// Diagram 1: System Context
export interface SystemContextActor {
  id: string;
  label: string;
  sub: string;
  colorKey: ColorKey;
  side: "left" | "right";
  top: number;
}

export interface SystemContextFlow {
  from: string;
  label: string;
  colorKey: ColorKey;
}

export interface SystemContextData {
  core: {
    label: string;
    sub: string;
    tags: string[];
  };
  actors: SystemContextActor[];
  flows: SystemContextFlow[];
}

// Diagram 2: Container Diagram
export interface ContainerNode {
  id: string;
  icon: string;
  label: string;
  tech: string;
  desc: string;
  colorKey: ColorKey;
  row: number;
  col: number;
}

export interface ContainerDiagramData {
  containers: ContainerNode[];
}

// Diagram 3: Component Diagram
export interface ComponentStep {
  icon: string;
  label: string;
  desc: string;
}

export interface ComponentFlow {
  id: string;
  label: string;
  colorKey: ColorKey;
  steps: ComponentStep[];
}

export interface ComponentDiagramData {
  flows: ComponentFlow[];
}

// Diagram 4: End-to-End Workflow
export interface E2EStep {
  id: number;
  icon: string;
  phase: string;
  label: string;
  colorKey: ColorKey;
  owner: OwnerKey;
  detail: string;
}

export interface E2EWorkflowData {
  steps: E2EStep[];
}

// Diagram 5: Swimlane Diagram
export interface SwimlaneStep {
  col: number;
  label: string;
  sub: string;
}

export interface SwimlaneLane {
  id: string;
  label: string;
  colorKey: ColorKey;
  steps: SwimlaneStep[];
}

export interface SwimlaneDiagramData {
  lanes: SwimlaneLane[];
  cols: number;
}

// Diagram 6: BPMN Flow
export type BPMNShape = "circle" | "circle-end" | "rect" | "diamond";
export type BPMNOwner = "AI" | "HUMAN" | "GOV";

export interface BPMNNode {
  id: string;
  x: number;
  y: number;
  type: "event" | "task" | "gateway";
  label: string;
  colorKey: ColorKey;
  shape: BPMNShape;
  owner?: BPMNOwner;
}

export interface BPMNEdge {
  from: string;
  to: string;
}

export interface BPMNBranchLabel {
  x: number;
  y: number;
  label: string;
}

export interface BPMNDiagramData {
  nodes: BPMNNode[];
  edges: BPMNEdge[];
  branchLabels: BPMNBranchLabel[];
}

// Diagram 7: AI vs Human Decision Boundary
export type DecisionZoneId = "AI" | "SHARED" | "HUMAN";

export interface DecisionItem {
  zone: DecisionZoneId;
  label: string;
  confidence: string;
  risk: string;
  detail: string;
  colorKey: ColorKey;
}

export interface DecisionZoneInfo {
  id: DecisionZoneId;
  label: string;
  colorKey: ColorKey;
  desc: string;
}

export interface DecisionBoundaryData {
  zones: DecisionZoneInfo[];
  items: DecisionItem[];
}

// Diagram 8: Solution Architecture
export interface ArchLayerItem {
  icon: string;
  label: string;
  sub: string;
}

export interface ArchLayer {
  id: string;
  label: string;
  colorKey: ColorKey;
  items: ArchLayerItem[];
}

export interface SolutionArchitectureData {
  layers: ArchLayer[];
}

// Registry metadata
export interface DiagramMeta {
  id: string;
  label: string;
  icon: string;
  sub: string;
}
