import { SwimlaneDiagramData } from "../types";

export const swimlaneDiagram: SwimlaneDiagramData = {
  cols: 11,
  lanes: [
    {
      id: "source", label: "Source Systems", colorKey: "blue",
      steps: [
        { col: 0, label: "Transaction Event", sub: "5,000+ daily via Kafka" },
        { col: 1, label: "KYC / Watchlist", sub: "Sanctions · PEP screens" },
      ],
    },
    {
      id: "ai", label: "AI Engine (Automated)", colorKey: "teal",
      steps: [
        { col: 2, label: "Risk Scoring", sub: "ML + Graph composite" },
        { col: 3, label: "Alert Generated", sub: "If score > threshold" },
        { col: 4, label: "Case Assembly", sub: "RAG + LLM summary" },
        { col: 7, label: "SAR Draft", sub: "LLM first draft" },
      ],
    },
    {
      id: "inv", label: "Investigator (Human)", colorKey: "orange",
      steps: [
        { col: 4, label: "Review Alert", sub: "AI-assisted workbench" },
        { col: 5, label: "Investigate", sub: "Accept / modify / override" },
        { col: 6, label: "Escalation Decision", sub: "Close / escalate / SAR" },
        { col: 8, label: "Review & Edit SAR", sub: "Human edits AI draft" },
      ],
    },
    {
      id: "comp", label: "Compliance Officer (Human)", colorKey: "violet",
      steps: [
        { col: 9, label: "Final SAR Approval", sub: "MFA sign-off required" },
        { col: 10, label: "File to FinCEN", sub: "XML/JSON submission" },
      ],
    },
    {
      id: "gov", label: "Governance & Audit", colorKey: "gold",
      steps: [
        { col: 0, label: "Log Ingestion", sub: "All events logged" },
        { col: 5, label: "Override Captured", sub: "Justification required" },
        { col: 9, label: "Approval Logged", sub: "Immutable audit trail" },
        { col: 10, label: "Reg. Evidence Pkg", sub: "Audit-ready export" },
      ],
    },
  ],
};
