import { SolutionArchitectureData } from "../types";

export const solutionArchitecture: SolutionArchitectureData = {
  layers: [
    {
      id: "users", label: "USER EXPERIENCE LAYER", colorKey: "teal",
      items: [
        { icon: "🕵️", label: "Investigator Workbench", sub: "Case dashboard · Risk scoring · Evidence viewer · AI insights · Timeline" },
        { icon: "👔", label: "Compliance Officer Console", sub: "Governance dashboards · Regulatory readiness · Policy intelligence" },
        { icon: "📊", label: "Executive Risk Cockpit", sub: "Enterprise risk heatmaps · Fraud trends · Compliance KPIs · Forecasting" },
        { icon: "🔍", label: "Audit & Review Portal", sub: "Model decisions · Override history · Evidence packages · Audit logs" },
      ],
    },
    {
      id: "api", label: "API GATEWAY & ORCHESTRATION", colorKey: "blue",
      items: [
        { icon: "🔀", label: "API Gateway", sub: "AuthN/AuthZ · Rate limiting · Routing · Versioning" },
        { icon: "⚙️", label: "Workflow Orchestration", sub: "Camunda/Temporal · Human-in-loop · SLA management · Escalations" },
        { icon: "🔐", label: "Identity & Access Mgmt", sub: "Azure AD · RBAC/ABAC · MFA · Zero-trust" },
      ],
    },
    {
      id: "intel", label: "INTELLIGENCE LAYER (AI + ML)", colorKey: "violet",
      items: [
        { icon: "🤖", label: "LLM & RAG Service", sub: "Azure OpenAI / Claude · Vector DB · Case summaries · SAR drafts · Policy Q&A" },
        { icon: "🕵️", label: "Fraud & Anomaly Models", sub: "XGBoost · Deep nets · MLflow · Behavioral patterns · Synthetic identity" },
        { icon: "🕸️", label: "Graph Intelligence", sub: "Neo4j · Fraud rings · Mule accounts · Network risk scoring" },
        { icon: "🎯", label: "Alert & Risk Scoring", sub: "Composite scoring · False positive filtering · Queue routing" },
      ],
    },
    {
      id: "svc", label: "CORE SERVICES LAYER", colorKey: "orange",
      items: [
        { icon: "📁", label: "Case Management", sub: "Lifecycle · Evidence · Decisions · Narratives · Links" },
        { icon: "🛡️", label: "Governance & Model Risk", sub: "MLflow registry · GRC integration · Explainability · Policy mapping" },
        { icon: "📋", label: "Audit & Logging", sub: "ELK/Splunk · Immutable logs · Audit trail · Compliance evidence" },
        { icon: "📊", label: "Reporting & Analytics", sub: "Power BI/Tableau · Operational dashboards · Regulatory metrics" },
      ],
    },
    {
      id: "data", label: "DATA PLATFORM LAYER", colorKey: "gold",
      items: [
        { icon: "🗄️", label: "Data Lakehouse", sub: "Delta Lake / Databricks · Raw + curated · Feature store · Lineage" },
        { icon: "📥", label: "Integration & Ingestion", sub: "Kafka / Event Hubs · dbt · Airflow · ETL pipelines · Data quality" },
        { icon: "🔒", label: "Security & Compliance", sub: "Encryption · Tokenization · Key mgmt · Immutable logs · PII masking" },
        { icon: "☸️", label: "Infrastructure & DevOps", sub: "AKS / Kubernetes · CI/CD · Azure Monitor · Blue-green deployment" },
      ],
    },
    {
      id: "src", label: "SOURCE SYSTEMS", colorKey: "blue",
      items: [
        { icon: "🏦", label: "Core Banking & Payments", sub: "Transaction streams · Account data · Payment rails" },
        { icon: "🪪", label: "KYC / AML Systems", sub: "Watchlists · Sanctions · PEP databases · Identity verification" },
        { icon: "💬", label: "Communications", sub: "Email · Chat · Call-center transcripts · Document stores" },
        { icon: "🏢", label: "Enterprise Systems", sub: "CRM · ERP · HR · Access management · Internal logs" },
      ],
    },
  ],
};
