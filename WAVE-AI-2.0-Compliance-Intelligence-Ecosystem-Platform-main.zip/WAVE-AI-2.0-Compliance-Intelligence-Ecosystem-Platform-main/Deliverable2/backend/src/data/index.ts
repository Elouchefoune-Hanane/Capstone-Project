import { DiagramMeta } from "../types";
import { systemContext } from "./systemContext";
import { containerDiagram } from "./containers";
import { componentDiagram } from "./componentFlows";
import { e2eWorkflow } from "./e2eWorkflow";
import { swimlaneDiagram } from "./swimlane";
import { bpmnDiagram } from "./bpmn";
import { decisionBoundary } from "./decisionBoundary";
import { solutionArchitecture } from "./solutionArchitecture";

export const DIAGRAM_META: DiagramMeta[] = [
  { id: "sysctx", label: "System Context", icon: "🌐", sub: "C4 Level 1" },
  { id: "container", label: "Container Diagram", icon: "📦", sub: "C4 Level 2" },
  { id: "component", label: "Component Diagram", icon: "⚙️", sub: "C4 Level 3" },
  { id: "e2e", label: "End-to-End Workflow", icon: "🔄", sub: "Full Flow" },
  { id: "swimlane", label: "Swimlane Diagram", icon: "🏊", sub: "Tx → SAR" },
  { id: "bpmn", label: "BPMN Flow", icon: "📐", sub: "Process Model" },
  { id: "boundary", label: "AI vs Human Boundary", icon: "⚖️", sub: "Decision Map" },
  { id: "arch", label: "Solution Architecture", icon: "🏗️", sub: "Full Stack" },
];

export const DIAGRAM_DATA: Record<string, unknown> = {
  sysctx: systemContext,
  container: containerDiagram,
  component: componentDiagram,
  e2e: e2eWorkflow,
  swimlane: swimlaneDiagram,
  bpmn: bpmnDiagram,
  boundary: decisionBoundary,
  arch: solutionArchitecture,
};
