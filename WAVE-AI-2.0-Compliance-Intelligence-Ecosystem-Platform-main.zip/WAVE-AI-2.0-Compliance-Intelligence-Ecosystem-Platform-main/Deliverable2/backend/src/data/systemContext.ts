import { SystemContextData } from "../types";

export const systemContext: SystemContextData = {
  core: {
    label: "Compliance Intelligence\nEcosystem (CIE)",
    sub:
      "AI-powered platform for fraud detection,\nalert prioritization, case acceleration,\ndocumentation automation, governance\noversight, regulatory readiness &\nhuman accountability",
    tags: ["FRAUD DETECT", "ALERT TRIAGE", "CASE MGMT", "SAR DRAFT", "GOVERNANCE", "REG READY"],
  },
  actors: [
    { id: "src", label: "Source Systems", sub: "Core Banking · Payments · KYC/AML\nCards · Lending · CRM · ERP · HR\nEmail · Chat · Call-Center", colorKey: "blue", side: "left", top: 160 },
    { id: "user", label: "Internal Users", sub: "Investigators · Compliance Officers\nRisk & Audit Teams\nExecutives (CRO · CCO · CIO · CFO)", colorKey: "teal", side: "left", top: 380 },
    { id: "cust", label: "Customers &\nCounterparties", sub: "Generate transactions & KYC data\nconsumed by CIE (indirect)", colorKey: "muted", side: "left", top: 580 },
    { id: "reg", label: "Regulators &\nExternal Bodies", sub: "Receive SAR/STR filings\nRegulatory reports · Audit evidence\nFinCEN · OCC · CFPB · FINRA", colorKey: "orange", side: "right", top: 280 },
    { id: "gov", label: "Governance &\nCompliance Bodies", sub: "Model risk oversight\nPolicy approvals · Audit findings", colorKey: "violet", side: "right", top: 500 },
  ],
  flows: [
    { from: "src", label: "Transaction streams · KYC data\nAML watchlists · Sanctions · Logs", colorKey: "blue" },
    { from: "user", label: "Investigations · Approvals\nCase decisions · Overrides", colorKey: "teal" },
    { from: "cust", label: "Transaction initiation\n(indirect via source systems)", colorKey: "muted" },
    { from: "reg", label: "SAR/STR filings · Exam requests\nRegulatory reports · Evidence", colorKey: "orange" },
    { from: "gov", label: "Model approvals · Policy directives\nAudit findings", colorKey: "violet" },
  ],
};
