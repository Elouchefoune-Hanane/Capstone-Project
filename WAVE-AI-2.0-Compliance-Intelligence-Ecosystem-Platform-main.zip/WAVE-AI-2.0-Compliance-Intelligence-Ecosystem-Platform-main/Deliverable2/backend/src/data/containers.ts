import { ContainerDiagramData } from "../types";

export const containerDiagram: ContainerDiagramData = {
  containers: [
    { id: "fe", icon: "🖥️", label: "Web Frontend", tech: "React / Next.js", desc: "Investigator & Compliance Portal. Case & alert workbench, AI summaries, dashboards, governance views. Users: Investigators, Compliance Officers, Risk/Audit, Executives.", colorKey: "teal", row: 0, col: 1 },
    { id: "gw", icon: "🔀", label: "API Gateway", tech: "Azure API Mgmt / Kong", desc: "Single entry point for UI and integrations. Handles AuthN/AuthZ, rate limiting, request routing, and API versioning.", colorKey: "blue", row: 1, col: 0 },
    { id: "wf", icon: "⚙️", label: "Orchestration & Workflow", tech: "Camunda / Temporal", desc: "Investigation workflows, human-in-the-loop approvals, escalations, SLAs, task routing. Manages the full lifecycle of compliance actions.", colorKey: "violet", row: 1, col: 1 },
    { id: "iam", icon: "🔐", label: "Identity & Access Mgmt", tech: "Azure AD / Entra / Okta", desc: "SSO, RBAC/ABAC enforcement, MFA, conditional access. Controls who can see what data and perform which actions.", colorKey: "orange", row: 1, col: 2 },
    { id: "cm", icon: "📁", label: "Case Management Service", tech: "Python/FastAPI or .NET", desc: "Case lifecycle: create, update, close. Links alerts, transactions, documents, decisions. Stores narratives and evidence references.", colorKey: "teal", row: 2, col: 0 },
    { id: "ar", icon: "🎯", label: "Alert & Risk Scoring", tech: "Python Microservice", desc: "Aggregates ML model outputs (fraud, AML, graph). Computes composite risk scores. Prioritizes and routes alerts to investigator queues.", colorKey: "red", row: 2, col: 1 },
    { id: "llm", icon: "🤖", label: "LLM & RAG Service", tech: "Azure OpenAI / Claude API", desc: "Case summaries, SAR drafts, policy Q&A. Retrieval-augmented generation over policies, regulations, procedures, and historical cases.", colorKey: "violet", row: 2, col: 2 },
    { id: "fraud", icon: "🕵️", label: "Fraud & Anomaly Models", tech: "MLflow / Azure ML", desc: "Real-time and batch scoring of transactions. PyTorch/XGBoost ML models for fraud detection, behavioral anomaly, synthetic identity.", colorKey: "red", row: 3, col: 0 },
    { id: "graph", icon: "🕸️", label: "Graph Intelligence", tech: "Neo4j / TigerGraph", desc: "Entity and relationship graph. Fraud ring detection, network risk scoring, mule account identification, and graph queries for investigators.", colorKey: "blue", row: 3, col: 1 },
    { id: "dp", icon: "🗄️", label: "Data Platform", tech: "Databricks / Snowflake", desc: "Lakehouse + warehouse. Raw and curated data, feature store for ML models, regulatory and BI reporting. Delta Lake architecture.", colorKey: "gold", row: 3, col: 2 },
    { id: "ing", icon: "📥", label: "Integration & Ingestion", tech: "Kafka / Event Hubs / dbt", desc: "Streaming and batch ingestion from all source systems. Data quality, normalization, schema enforcement, and lineage tracking.", colorKey: "blue", row: 4, col: 0 },
    { id: "gov", icon: "🛡️", label: "Governance & Model Risk", tech: "MLflow + GRC / ServiceNow", desc: "Model inventory, approvals, performance monitoring. Policy-model-control mappings. Explainability (SHAP/LIME) documentation.", colorKey: "gold", row: 4, col: 1 },
    { id: "audit", icon: "📋", label: "Audit & Logging Service", tech: "ELK / OpenSearch / Splunk", desc: "Immutable logs of all user actions, model calls, and data access. Searchable audit trail for regulators and internal audit teams.", colorKey: "orange", row: 4, col: 2 },
  ],
};
