import { DecisionBoundaryData } from "../types";

export const decisionBoundary: DecisionBoundaryData = {
  zones: [
    { id: "AI", label: "AI Autonomous Zone", colorKey: "teal", desc: "AI acts independently. Full explainability required. Human reviews outputs periodically." },
    { id: "SHARED", label: "Human-AI Collaboration", colorKey: "violet", desc: "AI recommends. Human decides. Every decision captured with reasoning." },
    { id: "HUMAN", label: "Human Authority Zone", colorKey: "orange", desc: "Humans make ALL decisions. AI may provide information only. No AI authorization." },
  ],
  items: [
    { zone: "AI", label: "Transaction Risk Scoring", confidence: "High", risk: "Low", detail: "Every transaction scored by ML models in <100ms. No human bottleneck. Full SHAP explainability.", colorKey: "teal" },
    { zone: "AI", label: "Alert Prioritization & Routing", confidence: "High", risk: "Low", detail: "AI ranks and routes 5,000+ daily alerts. Reduces investigator queue by 70%. Human reviews prioritization logic quarterly.", colorKey: "teal" },
    { zone: "AI", label: "False Positive Filtering", confidence: "High", risk: "Low", detail: "Historical pattern matching filters low-risk alerts. Reduces false positives from 98% to <60%. Audited monthly.", colorKey: "teal" },
    { zone: "AI", label: "Case Data Aggregation", confidence: "High", risk: "Low", detail: "AI assembles all case artifacts: transactions, KYC, history, documents. Purely data collection — no decision made.", colorKey: "teal" },
    { zone: "AI", label: "SAR First Draft Generation", confidence: "Med", risk: "Med", detail: "LLM produces SAR draft. Mandatory human review and edit before any submission. AI draft is starting point only.", colorKey: "teal" },
    { zone: "AI", label: "Regulatory Change Monitoring", confidence: "High", risk: "Low", detail: "Continuously scans regulatory updates. Flags new requirements for human compliance officer review.", colorKey: "teal" },
    { zone: "SHARED", label: "Investigation Recommendations", confidence: "Med", risk: "Med", detail: "AI suggests next investigative steps. Investigator decides which to follow. Override with justification always available.", colorKey: "violet" },
    { zone: "SHARED", label: "Risk Narrative Generation", confidence: "Med", risk: "Med", detail: "LLM generates risk narrative from case data. Investigator must validate accuracy before it enters case record.", colorKey: "violet" },
    { zone: "SHARED", label: "Compliance Gap Analysis", confidence: "Med", risk: "Med", detail: "AI identifies policy gaps. Compliance officer reviews, prioritizes, and authorizes remediation actions.", colorKey: "violet" },
    { zone: "SHARED", label: "Typology Pattern Detection", confidence: "Med", risk: "High", detail: "AI flags emerging fraud typologies. Human expert validates pattern before new detection rule is deployed.", colorKey: "violet" },
    { zone: "HUMAN", label: "SAR Filing Authorization", confidence: "N/A", risk: "High", detail: "ONLY licensed Compliance Officer can authorize and submit SARs to FinCEN. No AI override possible.", colorKey: "orange" },
    { zone: "HUMAN", label: "Law Enforcement Referral", confidence: "N/A", risk: "High", detail: "Any referral to law enforcement requires senior human authorization with documented justification.", colorKey: "orange" },
    { zone: "HUMAN", label: "Account Restriction / Closure", confidence: "N/A", risk: "High", detail: "Customer relationship decisions require human judgment. AI may flag — human must authorize.", colorKey: "orange" },
    { zone: "HUMAN", label: "AI Model Override", confidence: "N/A", risk: "High", detail: "Investigators can override any AI decision. Override logged immutably with reason. Triggers model review if frequent.", colorKey: "orange" },
    { zone: "HUMAN", label: "Model Retirement / Retraining", confidence: "N/A", risk: "High", detail: "Governance committee authorizes all model lifecycle decisions. AI cannot modify itself.", colorKey: "orange" },
    { zone: "HUMAN", label: "Regulatory Response Sign-Off", confidence: "N/A", risk: "High", detail: "Executive sign-off required on all regulatory communications. No automated regulatory submissions.", colorKey: "orange" },
  ],
};
