import { E2EWorkflowData } from "../types";

export const e2eWorkflow: E2EWorkflowData = {
  steps: [
    { id: 1, icon: "📥", phase: "INTAKE", label: "Transaction Intake", colorKey: "blue", owner: "AI", detail: "5,000+ daily transactions ingested via Kafka/Event Hubs from core banking, payments, cards, and lending systems. Data normalized, enriched with KYC/watchlist data." },
    { id: 2, icon: "⚡", phase: "DETECT", label: "Real-Time Risk Scoring", colorKey: "red", owner: "AI", detail: "ML models (XGBoost + graph neural nets) score every transaction. SHAP values generated for explainability. Composite risk score computed combining fraud, network, and customer risk." },
    { id: 3, icon: "🎯", phase: "PRIORITIZE", label: "Alert Prioritization", colorKey: "orange", owner: "AI", detail: "AI ranks alerts by risk score, regulatory impact, and investigator queue capacity. False positives filtered via historical pattern learning. Alerts routed to correct team." },
    { id: 4, icon: "📂", phase: "INVESTIGATE", label: "Case Assembly (Co-Pilot)", colorKey: "violet", owner: "AI+H", detail: "Investigator Co-Pilot assembles: all linked transactions, KYC data, prior history, entity graph. RAG retrieves relevant policies. LLM generates case summary and risk narrative." },
    { id: 5, icon: "👤", phase: "REVIEW", label: "Human Investigation", colorKey: "teal", owner: "HUMAN", detail: "Licensed investigator reviews AI-generated case. Can accept, modify, or override any AI suggestion. Every override captured with mandatory justification reason." },
    { id: 6, icon: "⚖️", phase: "DECIDE", label: "Escalation / SAR Decision", colorKey: "gold", owner: "HUMAN", detail: "Investigator decides: close alert, request more info, or escalate to SAR filing. Escalation paths: supervisor review, legal, law enforcement referral. All human-authorized." },
    { id: 7, icon: "📝", phase: "DOCUMENT", label: "SAR Auto-Draft", colorKey: "violet", owner: "AI+H", detail: "LLM generates SAR draft from case data, evidence, and typology library. Compliance officer reviews, edits, and approves. Mandatory human sign-off before any filing." },
    { id: 8, icon: "✅", phase: "APPROVE", label: "Compliance Sign-Off", colorKey: "orange", owner: "HUMAN", detail: "Only licensed Compliance Officer can authorize SAR submission. Full workflow approval with MFA. Reviewer identity, timestamp, and justification logged immutably." },
    { id: 9, icon: "📤", phase: "FILE", label: "Regulatory Filing", colorKey: "blue", owner: "HUMAN", detail: "SAR/STR filed to FinCEN in required XML/JSON format. Confirmation received and stored. Audit-ready documentation package auto-assembled with chain of custody." },
    { id: 10, icon: "🛡️", phase: "AUDIT", label: "Governance & Audit", colorKey: "gold", owner: "GOV", detail: "All actions immutably logged: model calls, decisions, overrides, filings. Regulatory readiness score updated. Model drift and bias monitoring triggered. Executive dashboard updated." },
  ],
};
