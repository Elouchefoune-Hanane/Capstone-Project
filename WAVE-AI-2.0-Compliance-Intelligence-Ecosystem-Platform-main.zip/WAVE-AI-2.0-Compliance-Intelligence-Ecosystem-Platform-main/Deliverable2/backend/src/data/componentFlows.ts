import { ComponentDiagramData } from "../types";

export const componentDiagram: ComponentDiagramData = {
  flows: [
    {
      id: "alert",
      label: "A. Alert Generation & Prioritization",
      colorKey: "red",
      steps: [
        { icon: "📡", label: "Transaction Ingestion", desc: "Reads events from Kafka/Event Hubs. Normalizes and enriches transactions with KYC, account, and watchlist data." },
        { icon: "🧠", label: "Fraud Scoring", desc: "Calls ML models (XGBoost, deep nets). Returns base fraud risk score + SHAP explanation features for every transaction." },
        { icon: "🕸️", label: "Graph Risk", desc: "Queries graph DB: node centrality, known fraud rings, suspicious relationships. Returns network risk score." },
        { icon: "⚖️", label: "Composite Risk Engine", desc: "Combines: fraud score + graph risk + customer risk + regulatory impact. Outputs: final risk score, priority level, recommended routing." },
        { icon: "🔔", label: "Alert Creation", desc: "Creates alert records. Links to transactions, customers, accounts. Pushes to Case Management when risk thresholds are met." },
      ],
    },
    {
      id: "investigation",
      label: "B. Case Investigation & AI Assistance",
      colorKey: "violet",
      steps: [
        { icon: "📂", label: "Case Aggregator", desc: "Collects: linked alerts, transactions, KYC data, prior case history, communications, and documents into a unified case object." },
        { icon: "🔄", label: "Evidence Normalizer", desc: "Converts structured + unstructured data into text snippets, JSON structures, and graph references for LLM consumption." },
        { icon: "✍️", label: "LLM Prompt Builder", desc: "Builds structured prompts with case facts, policies, risk appetite. Ensures grounding via RAG to prevent hallucination." },
        { icon: "🔍", label: "RAG Retriever", desc: "Queries vector store for: relevant policies, regulations, similar historical cases, and AML typologies." },
        { icon: "🤖", label: "LLM Inference", desc: "Generates: case summary, risk narrative, suggested investigative actions, and draft SAR/STR text." },
        { icon: "👤", label: "Investigator Action", desc: "Allows: accept/modify AI suggestions, add manual notes, approve/decline SAR drafts. Captures justification for every override." },
      ],
    },
    {
      id: "documentation",
      label: "C. Documentation Automation & Regulatory Reporting",
      colorKey: "teal",
      steps: [
        { icon: "📋", label: "SAR/STR Template Engine", desc: "Defines schema for regulatory reports. Maps case data fields to FinCEN/regulator-required fields and report formats." },
        { icon: "📝", label: "Narrative Generator", desc: "Uses LLM to produce: clear structured narratives, typology descriptions, and supporting evidence references." },
        { icon: "✅", label: "Compliance Review", desc: "Human workflow step: review, edits, and approvals. Logs reviewer identity, role, and timestamp — immutable record." },
        { icon: "📤", label: "Regulatory Export", desc: "Generates XML/JSON/PDF per regulator format. Integrates with filing channels. Full audit chain of custody preserved." },
      ],
    },
    {
      id: "governance",
      label: "D. Governance & Human Accountability",
      colorKey: "gold",
      steps: [
        { icon: "🗂️", label: "Model Registry", desc: "Stores: model versions, validation results, approval status, owners and reviewers. Tracks full model lifecycle." },
        { icon: "💡", label: "Explainability", desc: "Computes SHAP/LIME explanations. Exposes human-readable 'why' for each model decision to investigators and auditors." },
        { icon: "🗺️", label: "Policy Mapping", desc: "Links: controls → models → alerts → regulations. Enables impact analysis when policies or regulations change." },
        { icon: "🔐", label: "RBAC/ABAC Enforcement", desc: "Checks user role, region, business unit, and case sensitivity. Controls granular access to data and all system actions." },
        { icon: "📜", label: "Audit Trail", desc: "Logs: every model call, user decision, override and justification. Provides query interface for audit teams and regulators." },
      ],
    },
  ],
};
