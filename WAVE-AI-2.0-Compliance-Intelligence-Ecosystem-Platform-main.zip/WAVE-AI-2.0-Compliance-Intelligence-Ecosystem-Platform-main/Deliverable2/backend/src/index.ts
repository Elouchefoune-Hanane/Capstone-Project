import express from "express";
import cors from "cors";
import { diagramsRouter } from "./routes/diagrams";

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 4000;

app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.use("/api/diagrams", diagramsRouter);

app.listen(PORT, () => {
  console.log(`CIE architecture API listening on http://localhost:${PORT}`);
});
