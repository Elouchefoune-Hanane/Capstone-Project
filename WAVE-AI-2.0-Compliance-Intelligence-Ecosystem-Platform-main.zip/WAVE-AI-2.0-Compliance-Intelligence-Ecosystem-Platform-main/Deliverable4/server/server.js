require("dotenv").config();
const express = require("express");
const cors    = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

// ── DATA ──────────────────────────────────────────────────────────────────────
const HIGH_RISK_COUNTRIES = [
  "Russia","Nigeria","Belarus","Ukraine","Iran","North Korea","Syria",
  "Myanmar","Cuba","Venezuela","Libya","Sudan","Yemen","Somalia","Iraq",
];

const transactions = [
  { id:"TXN-001", customer:"Carlos Mendez",    customerId:"C001", amount:9500,   currency:"USD", channel:"ONLINE",  location:"Mexico",    riskScore:0.94, type:"Structuring",       status:"OPEN"   },
  { id:"TXN-002", customer:"Aisha Bello",      customerId:"C002", amount:47200,  currency:"EUR", channel:"WIRE",    location:"Nigeria",   riskScore:0.88, type:"Layering",          status:"OPEN"   },
  { id:"TXN-003", customer:"Wei Zhang",        customerId:"C003", amount:3200,   currency:"CNY", channel:"ONLINE",  location:"China",     riskScore:0.41, type:"Low Risk",          status:"CLOSED" },
  { id:"TXN-004", customer:"Boris Petrov",     customerId:"C004", amount:82000,  currency:"USD", channel:"CASH",    location:"Russia",    riskScore:0.97, type:"Money Laundering",  status:"OPEN"   },
  { id:"TXN-005", customer:"Fatima Al-Rashid", customerId:"C005", amount:15600,  currency:"AED", channel:"ONLINE",  location:"UAE",       riskScore:0.73, type:"Shell Company",     status:"OPEN"   },
  { id:"TXN-006", customer:"Marcus Johnson",   customerId:"C006", amount:1200,   currency:"USD", channel:"ATM",     location:"USA",       riskScore:0.18, type:"Low Risk",          status:"CLOSED" },
  { id:"TXN-007", customer:"Sofia Rossi",      customerId:"C007", amount:28900,  currency:"EUR", channel:"WIRE",    location:"Italy",     riskScore:0.66, type:"Unusual Pattern",   status:"OPEN"   },
  { id:"TXN-008", customer:"Dmitri Volkov",    customerId:"C008", amount:95000,  currency:"USD", channel:"ONLINE",  location:"Ukraine",   riskScore:0.99, type:"Fraud Ring",        status:"OPEN"   },
  { id:"TXN-009", customer:"Priya Sharma",     customerId:"C009", amount:4500,   currency:"INR", channel:"MOBILE",  location:"India",     riskScore:0.29, type:"Low Risk",          status:"CLOSED" },
  { id:"TXN-010", customer:"Ahmed Hassan",     customerId:"C010", amount:61000,  currency:"USD", channel:"WIRE",    location:"Egypt",     riskScore:0.85, type:"Sanctions Risk",    status:"OPEN"   },
  { id:"TXN-011", customer:"Li Wei",           customerId:"C011", amount:9800,   currency:"USD", channel:"ONLINE",  location:"Hong Kong", riskScore:0.91, type:"Structuring",       status:"OPEN"   },
  { id:"TXN-012", customer:"Maria Santos",     customerId:"C012", amount:6700,   currency:"BRL", channel:"MOBILE",  location:"Brazil",    riskScore:0.52, type:"Moderate Risk",     status:"OPEN"   },
  { id:"TXN-013", customer:"Ivan Petrov",      customerId:"C013", amount:120000, currency:"USD", channel:"WIRE",    location:"Belarus",   riskScore:0.98, type:"High-Value Fraud",  status:"OPEN"   },
  { id:"TXN-014", customer:"Grace Okafor",     customerId:"C014", amount:8900,   currency:"NGN", channel:"ONLINE",  location:"Nigeria",   riskScore:0.77, type:"Mule Account",      status:"OPEN"   },
  { id:"TXN-015", customer:"John Smith",       customerId:"C015", amount:550,    currency:"USD", channel:"ATM",     location:"USA",       riskScore:0.09, type:"Low Risk",          status:"CLOSED" },
];

let auditLog = [];

// ── SCORING ───────────────────────────────────────────────────────────────────
function scoreTransaction(form) {
  let score = 0;
  const amt = Number(form.amount);
  if (amt > 50000)                           score += 0.45;
  else if (amt > 10000)                      score += 0.30;
  else if (amt > 9000 && amt < 10000)        score += 0.40;
  if (form.channel === "WIRE")               score += 0.20;
  else if (form.channel === "ONLINE")        score += 0.15;
  else if (form.channel === "CASH")          score += 0.25;
  if (HIGH_RISK_COUNTRIES.includes(form.location)) score += 0.30;
  return Math.min(score, 1);
}

// ── SAR TEMPLATES ─────────────────────────────────────────────────────────────
const SAR_TEMPLATES = {
  Structuring: (t) => `SUSPICIOUS ACTIVITY REPORT — DRAFT

SUBJECT: ${t.customer} (ID: ${t.customerId})
TRANSACTION: ${t.id} | ${t.currency} ${t.amount.toLocaleString()} | ${t.channel} | ${t.location}
TYPOLOGY: Structuring (Smurfing)
RISK SCORE: ${(t.riskScore * 100).toFixed(0)}%

BACKGROUND:
${t.customer} conducted a transaction of ${t.currency} ${t.amount.toLocaleString()} via ${t.channel} channel from ${t.location}.

DESCRIPTION OF SUSPICIOUS ACTIVITY:
The transaction amount of ${t.currency} ${t.amount.toLocaleString()} appears deliberately structured to remain just below the $10,000 CTR reporting threshold. This is consistent with the known typology of structuring (smurfing). The transaction was executed via ${t.channel} from ${t.location}, a jurisdiction flagged as elevated risk.

PARTIES INVOLVED:
Primary Subject: ${t.customer} (Customer ID: ${t.customerId})
Transaction Origin: ${t.location}
Channel Used: ${t.channel}

INDICATORS / TYPOLOGIES:
• Transaction amount (${t.currency} ${t.amount.toLocaleString()}) is just below the $10,000 reporting threshold
• ${t.location} is designated as an elevated-risk jurisdiction
• ${t.channel} channel used — consistent with layering techniques
• No clear legitimate business purpose identified

CONCLUSION AND RECOMMENDED ACTION:
Based on the above analysis, this transaction exhibits characteristics consistent with structuring. SAR filing with FinCEN is recommended. Further investigation should include review of all transactions from ${t.customer} over the past 90 days.

AI-ASSISTED DRAFT — REQUIRES COMPLIANCE OFFICER REVIEW AND APPROVAL BEFORE FILING`,

  "Money Laundering": (t) => `SUSPICIOUS ACTIVITY REPORT — DRAFT

SUBJECT: ${t.customer} (ID: ${t.customerId})
TRANSACTION: ${t.id} | ${t.currency} ${t.amount.toLocaleString()} | ${t.channel} | ${t.location}
TYPOLOGY: Money Laundering — Layering
RISK SCORE: ${(t.riskScore * 100).toFixed(0)}%

BACKGROUND:
${t.customer} conducted a high-value ${t.channel} transaction of ${t.currency} ${t.amount.toLocaleString()} originating from ${t.location}. Risk score: ${(t.riskScore * 100).toFixed(0)}%.

DESCRIPTION OF SUSPICIOUS ACTIVITY:
The transaction of ${t.currency} ${t.amount.toLocaleString()} via ${t.channel} represents an unusually large movement of funds. The origin jurisdiction (${t.location}) is associated with elevated financial crime risk. The pattern is consistent with layering — a stage of money laundering where illicit funds are moved to obscure their origin.

PARTIES INVOLVED:
Primary Subject: ${t.customer} (Customer ID: ${t.customerId})
Transaction Origin: ${t.location}
Channel: ${t.channel} | Amount: ${t.currency} ${t.amount.toLocaleString()}

INDICATORS / TYPOLOGIES:
• Large transaction (${t.currency} ${t.amount.toLocaleString()}) with no documented business purpose
• Origin from high-risk jurisdiction: ${t.location}
• Transaction velocity inconsistent with customer's established profile
• ${t.channel} channel suggests attempt to distance funds from source

CONCLUSION AND RECOMMENDED ACTION:
Immediate SAR filing with FinCEN is recommended. Account should be placed under enhanced monitoring. Consider temporary restriction of outgoing wire transfers pending investigation.

AI-ASSISTED DRAFT — REQUIRES COMPLIANCE OFFICER REVIEW AND APPROVAL BEFORE FILING`,

  default: (t) => `SUSPICIOUS ACTIVITY REPORT — DRAFT

SUBJECT: ${t.customer} (ID: ${t.customerId})
TRANSACTION: ${t.id} | ${t.currency} ${t.amount.toLocaleString()} | ${t.channel} | ${t.location}
TYPOLOGY: ${t.type}
RISK SCORE: ${(t.riskScore * 100).toFixed(0)}%

BACKGROUND:
${t.customer} conducted a transaction of ${t.currency} ${t.amount.toLocaleString()} via ${t.channel} from ${t.location}. The AI fraud detection engine assigned a risk score of ${(t.riskScore * 100).toFixed(0)}%, exceeding the threshold for SAR review.

DESCRIPTION OF SUSPICIOUS ACTIVITY:
The transaction exhibits characteristics consistent with ${t.type}. The combination of amount (${t.currency} ${t.amount.toLocaleString()}), origin (${t.location}), and channel (${t.channel}) generated a composite risk score of ${(t.riskScore * 100).toFixed(0)}%.

PARTIES INVOLVED:
Primary Subject: ${t.customer} (Customer ID: ${t.customerId})
Transaction: ${t.id}
Location: ${t.location} | Channel: ${t.channel}

INDICATORS / TYPOLOGIES:
• Risk classification: ${t.type}
• Composite AI risk score: ${(t.riskScore * 100).toFixed(0)}% (threshold: 70%)
• Origin: ${t.location} ${HIGH_RISK_COUNTRIES.includes(t.location) ? "(HIGH-RISK JURISDICTION)" : ""}
• Transaction amount: ${t.currency} ${t.amount.toLocaleString()}

CONCLUSION AND RECOMMENDED ACTION:
Given the risk indicators identified, filing a SAR with FinCEN is recommended. The investigator should review all account activity for the past 180 days.

AI-ASSISTED DRAFT — REQUIRES COMPLIANCE OFFICER REVIEW AND APPROVAL BEFORE FILING`,
};

// ── AI SUMMARIES ──────────────────────────────────────────────────────────────
const AI_SUMMARIES = {
  Structuring: (t) => `AI CASE ANALYSIS

This transaction from ${t.customer} in ${t.location} shows strong structuring indicators. The amount of ${t.currency} ${t.amount.toLocaleString()} is deliberately positioned just below the $10,000 mandatory reporting threshold — a pattern known as smurfing.

KEY RISK FACTORS:
• Amount just below CTR threshold
• ${t.location} is an elevated-risk jurisdiction
• ${t.channel} channel is consistent with layering tactics

RECOMMENDED NEXT STEPS:
1. Review all transactions from this customer in the last 90 days
2. Check for similar structured transactions across multiple accounts
3. Escalate to SAR filing — structuring is itself a federal crime
4. Place customer under enhanced monitoring`,

  "Money Laundering": (t) => `AI CASE ANALYSIS

High-priority alert. ${t.customer} transmitted ${t.currency} ${t.amount.toLocaleString()} via ${t.channel} from ${t.location}. Risk score: ${(t.riskScore * 100).toFixed(0)}% — one of the highest in the current queue.

KEY RISK FACTORS:
• Very large transaction amount with no documented business purpose
• ${t.location} is a jurisdiction under heightened AML scrutiny
• Wire transfer channel consistent with layering stage of money laundering
• Customer profile inconsistency detected

RECOMMENDED NEXT STEPS:
1. Immediately request account hold pending investigation
2. File SAR with FinCEN within 30 days
3. Conduct full KYC refresh on ${t.customer}
4. Check for related accounts receiving or sending funds`,

  default: (t) => `AI CASE ANALYSIS

Transaction ${t.id} from ${t.customer} has been flagged with a ${(t.riskScore * 100).toFixed(0)}% risk score. The combination of transaction amount (${t.currency} ${t.amount.toLocaleString()}), origin (${t.location}), and channel (${t.channel}) triggered the fraud detection engine.

KEY RISK FACTORS:
• Risk typology: ${t.type}
• ${HIGH_RISK_COUNTRIES.includes(t.location) ? `${t.location} is on the high-risk jurisdiction watchlist` : "Elevated risk pattern detected"}
• Risk score ${(t.riskScore * 100).toFixed(0)}% exceeds 70% SAR review threshold

RECOMMENDED NEXT STEPS:
1. Review full customer transaction history
2. Verify customer identity and source of funds
3. Assess whether SAR filing is warranted
4. Document investigation findings and decision`,
};

function getSarTemplate(type) {
  const key = Object.keys(SAR_TEMPLATES).find((k) => type.includes(k));
  return SAR_TEMPLATES[key] || SAR_TEMPLATES.default;
}

function getSummaryTemplate(type) {
  const key = Object.keys(AI_SUMMARIES).find((k) => type.includes(k));
  return AI_SUMMARIES[key] || AI_SUMMARIES.default;
}

// ── ROUTES ────────────────────────────────────────────────────────────────────

// GET /api/transactions
app.get("/api/transactions", (_req, res) => {
  res.json(transactions);
});

// POST /api/transactions/score
app.post("/api/transactions/score", (req, res) => {
  const form      = req.body;
  const riskScore = scoreTransaction(form);
  const txn = {
    id:         `TXN-${Date.now()}`,
    customer:   form.customer,
    customerId: `C-${Date.now()}`,
    amount:     Number(form.amount),
    currency:   form.currency,
    channel:    form.channel,
    location:   form.location,
    riskScore,
    type:   "Manual Entry",
    status: riskScore >= 0.7 ? "OPEN" : "CLOSED",
  };
  res.json({ transaction: txn });
});

// GET /api/audit
app.get("/api/audit", (_req, res) => {
  res.json(auditLog);
});

// POST /api/audit
app.post("/api/audit", (req, res) => {
  const entry = {
    id:   Date.now(),
    user: req.body.user,
    action: req.body.action,
    entity: req.body.entity,
    detail: req.body.detail,
    ts:   new Date().toLocaleTimeString(),
  };
  auditLog.unshift(entry);
  res.status(201).json(entry);
});

// POST /api/sar  — body: { transaction }
app.post("/api/sar", (req, res) => {
  const t = req.body.transaction;
  if (!t) return res.status(400).json({ error: "transaction required" });
  res.json({ text: getSarTemplate(t.type)(t) });
});

// POST /api/summary  — body: { transaction }
app.post("/api/summary", (req, res) => {
  const t = req.body.transaction;
  if (!t) return res.status(400).json({ error: "transaction required" });
  res.json({ text: getSummaryTemplate(t.type)(t) });
});

// ── START ─────────────────────────────────────────────────────────────────────
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`WAVE AI Compliance Server running on http://localhost:${PORT}`);
});
