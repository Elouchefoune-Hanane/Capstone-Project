import { useState, useEffect } from "react";
import { C } from "./constants";
import { Transaction } from "./types";
import { getTransactions, addAuditEntry } from "./api";
import Dashboard from "./components/Dashboard";
import TransactionsView from "./components/TransactionsView";
import AlertsView from "./components/AlertsView";
import InvestigatorView from "./components/InvestigatorView";
import AuditView from "./components/AuditView";

type View = "dashboard" | "transactions" | "alerts" | "investigate" | "audit";

export default function App() {
  const [view, setView]               = useState<View>("dashboard");
  const [selectedTxn, setSelectedTxn] = useState<Transaction | null>(null);
  const [auditRefresh, setAuditRefresh] = useState(0);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading]         = useState(true);
  const [serverError, setServerError] = useState(false);

  useEffect(() => {
    getTransactions()
      .then((data) => {
        setTransactions(data);
        setServerError(false);
      })
      .catch(() => {
        setTransactions([]);
        setServerError(true);
      })
      .finally(() => setLoading(false));
  }, []);

  function triggerAuditRefresh() {
    setAuditRefresh((r) => r + 1);
  }

  function handleInvestigate(txn: Transaction) {
    setSelectedTxn(txn);
    setView("investigate");
    addAuditEntry({
      user: "Investigator",
      action: "CASE_OPENED",
      entity: txn.id,
      detail: `Investigation started on ${txn.customer} — ${txn.type}`,
    }).then(triggerAuditRefresh);
  }

  function handleTransactionSubmit(txn: Transaction) {
    setTransactions((prev) => [...prev, txn]);
    setSelectedTxn(txn);
    addAuditEntry({
      user: "Investigator",
      action: "TRANSACTION_SUBMITTED",
      entity: txn.id,
      detail: `Risk score: ${(txn.riskScore * 100).toFixed(0)}% — ${txn.riskScore >= 0.7 ? "Alert created" : "Auto-closed (low risk)"}`,
    }).then(triggerAuditRefresh);
  }

  const openAlerts = transactions.filter((t) => t.status === "OPEN");

  const navItems = [
    { id: "dashboard"    as View, label: "Dashboard",    icon: "📊" },
    { id: "transactions" as View, label: "Transactions", icon: "💳" },
    { id: "alerts"       as View, label: "Alerts",       icon: "🔔", badge: openAlerts.length || null },
    { id: "audit"        as View, label: "Audit Trail",  icon: "📋" },
  ];

  const isAlertsActive = view === "alerts" || view === "investigate";

  return (
    <div style={{
      height: "100vh", display: "flex", flexDirection: "column",
      background: C.bg, fontFamily: "'DM Sans','Segoe UI',sans-serif",
      color: C.text, overflow: "hidden",
    }}>
      {/* Top bar */}
      <div style={{
        display: "flex", alignItems: "center", justifyContent: "space-between",
        padding: "12px 24px", background: C.surf, borderBottom: `1px solid ${C.border}`,
        flexShrink: 0,
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{
            width: 32, height: 32, borderRadius: 8,
            background: `linear-gradient(135deg,${C.teal},${C.violet})`,
            display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16,
          }}>
            ⚡
          </div>
          <div>
            <div style={{ fontSize: 9, letterSpacing: 3, color: C.teal, fontWeight: 800 }}>WAVE AI</div>
            <div style={{ fontSize: 13, fontWeight: 800 }}>Compliance Command Center</div>
          </div>
        </div>

        <nav style={{ display: "flex", gap: 4 }}>
          {navItems.map((n) => {
            const active = n.id === view || (isAlertsActive && n.id === "alerts");
            return (
              <button
                key={n.id}
                onClick={() => setView(n.id)}
                style={{
                  display: "flex", alignItems: "center", gap: 6,
                  padding: "7px 14px", borderRadius: 8, cursor: "pointer", fontSize: 12,
                  background: active ? `${C.teal}15` : "transparent",
                  border: `1px solid ${active ? C.teal + "50" : "transparent"}`,
                  color: active ? C.teal : C.muted,
                  fontWeight: active ? 700 : 400, transition: "all 0.15s",
                }}
              >
                {n.icon} {n.label}
                {n.badge ? (
                  <span style={{
                    background: C.red, color: "#fff", borderRadius: "50%",
                    width: 16, height: 16, fontSize: 9, fontWeight: 800,
                    display: "flex", alignItems: "center", justifyContent: "center",
                  }}>
                    {n.badge}
                  </span>
                ) : null}
              </button>
            );
          })}
        </nav>

        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
          <div style={{
            width: 8, height: 8, borderRadius: "50%",
            background: serverError ? C.red : C.green,
            boxShadow: `0 0 6px ${serverError ? C.red : C.green}`,
          }} />
          <span style={{ fontSize: 11, color: C.muted }}>
            {serverError ? "Server offline" : "Live"} · MVP Demo · {new Date().toLocaleDateString()}
          </span>
        </div>
      </div>

      {/* Content */}
      <div style={{ flex: 1, overflowY: "auto", background: C.bg }}>
        {loading ? (
          <div style={{ textAlign: "center", padding: "80px 0", color: C.muted }}>
            <div style={{ fontSize: 40, marginBottom: 16 }}>⚡</div>
            <div style={{ fontSize: 14, color: C.teal }}>Loading transactions from server...</div>
          </div>
        ) : (
          <>
            {view === "dashboard"    && <Dashboard transactions={transactions} onNav={(v) => setView(v as View)} />}
            {view === "transactions" && <TransactionsView onSubmit={handleTransactionSubmit} />}
            {view === "alerts"       && <AlertsView transactions={transactions} onInvestigate={handleInvestigate} />}
            {view === "investigate"  && selectedTxn && (
              <InvestigatorView
                transaction={selectedTxn}
                onBack={() => setView("alerts")}
                onUpdateAudit={triggerAuditRefresh}
              />
            )}
            {view === "audit" && <AuditView refresh={auditRefresh} />}
          </>
        )}
      </div>

      {/* Status bar */}
      <div style={{
        flexShrink: 0, padding: "6px 24px",
        background: C.surf, borderTop: `1px solid ${C.border}`,
        display: "flex", justifyContent: "space-between", alignItems: "center",
        fontSize: 10, color: C.muted,
      }}>
        <span>⚡ WAVE AI · WIC × Microsoft AI Innovator Apprenticeship · 2026</span>
        <span>
          {openAlerts.length} open alerts ·{" "}
          <span style={{ color: serverError ? C.red : C.green }}>●</span>{" "}
          {serverError ? "Backend offline — start server on port 3001" : "All systems operational"}
        </span>
      </div>
    </div>
  );
}
