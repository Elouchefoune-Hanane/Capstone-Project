import { API_BASE } from "./constants";
import { Transaction, AuditEntry, TransactionForm } from "./types";

export async function getTransactions(): Promise<Transaction[]> {
  const res = await fetch(`${API_BASE}/transactions`);
  if (!res.ok) throw new Error("Failed to fetch transactions");
  return res.json();
}

export async function scoreTransaction(
  form: TransactionForm
): Promise<{ transaction: Transaction }> {
  const res = await fetch(`${API_BASE}/transactions/score`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(form),
  });
  if (!res.ok) throw new Error("Failed to score transaction");
  return res.json();
}

export async function getAuditLog(): Promise<AuditEntry[]> {
  const res = await fetch(`${API_BASE}/audit`);
  if (!res.ok) throw new Error("Failed to fetch audit log");
  return res.json();
}

export async function addAuditEntry(
  entry: Omit<AuditEntry, "id" | "ts">
): Promise<void> {
  await fetch(`${API_BASE}/audit`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(entry),
  });
}

export async function generateSar(transaction: Transaction): Promise<string> {
  const res = await fetch(`${API_BASE}/sar`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ transaction }),
  });
  if (!res.ok) throw new Error("Failed to generate SAR");
  const data = await res.json();
  return data.text;
}

export async function generateSummary(transaction: Transaction): Promise<string> {
  const res = await fetch(`${API_BASE}/summary`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ transaction }),
  });
  if (!res.ok) throw new Error("Failed to generate summary");
  const data = await res.json();
  return data.text;
}
