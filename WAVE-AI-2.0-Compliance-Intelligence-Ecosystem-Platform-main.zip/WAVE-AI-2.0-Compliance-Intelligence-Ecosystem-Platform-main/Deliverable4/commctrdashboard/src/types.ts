export interface Transaction {
  id: string;
  customer: string;
  customerId: string;
  amount: number;
  currency: string;
  channel: string;
  location: string;
  riskScore: number;
  type: string;
  status: "OPEN" | "CLOSED";
}

export interface AuditEntry {
  id: number;
  user: string;
  action: string;
  entity: string;
  detail: string;
  ts: string;
}

export interface TransactionForm {
  customer: string;
  amount: string;
  currency: string;
  channel: string;
  location: string;
}
