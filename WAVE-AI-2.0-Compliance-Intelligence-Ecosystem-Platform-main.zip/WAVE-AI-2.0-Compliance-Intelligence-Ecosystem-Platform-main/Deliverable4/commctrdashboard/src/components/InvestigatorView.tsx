import { useState, useEffect } from "react";
import { C, HIGH_RISK_COUNTRIES } from "../constants";
import { Transaction } from "../types";
import { getRiskColor } from "../utils";
import { generateSar, generateSummary, addAuditEntry } from "../api";
import RiskBadge from "./RiskBadge";

interface Props {
  transaction: Transaction;
  onBack: () => void;
  onUpdateAudit: () => void;
}

type Stage = "loading" | "ready" | "complete";

export default function InvestigatorView({ transaction, onBack, onUpdateAudit }: Props) {
  const t = transaction;

  const [stage, setStage]               = useState<Stage>("loading");
  const [sarText, setSarText]           = useState("");
  const [summary, setSummary]           = useState("");
  const [notes, setNotes]               = useState("");
  const [decision, setDecision]         = useState<string | null>(null);
  const [justification, setJustification] = useState("");

  useEffect(() => {
    Promise.all([generateSar(t), generateSummary(t)])
      .then(([sar, sum]) => {
        setSarText(sar);
        setSummary(sum);
        addAuditEntry({
          user: "AI System",
          action: "CASE_ASSEMBLED",
          entity: t.id,
          detail: "Evidence aggregated, summary generated, SAR draft ready",
        }).then(onUpdateAudit);
      })
      .catch(() => {
        setSarText("Backend unavailable — SAR generation requires the server on port 3001.");
        setSummary("Backend unavailable — AI summary requires the server on port 3001.");
      })
      .finally(() => setStage("ready"));
  }, [t.id]);

  function handleDecision(d: string) {
    if (!justification.trim()) return;
    setDecision(d);
    setStage("complete");
    const action = d === "APPROVE" ? "SAR_APPROVED" : d === "CLOSE" ? "CASE_CLOSED" : "ESCALATED";
    addAuditEntry({ user: "Investigator", action, entity: t.id, detail: justification }).then(onUpdateAudit);
  }

  return (
    <div style={{ padding: "28px 32px" }}>
      <button
        onClick={onBack}
        style={{ background: "transparent", border: "none", color: C.muted, cursor: "pointer", fontSize: 12, marginBottom: 20, padding: 0 }}
      >
        ← Back to Alerts
      </button>

      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: C.violet, fontWeight: 800 }}>INVESTIGATOR CO-PILOT</div>
        <RiskBadge score={t.riskScore} />
        <span style={{ fontSize: 10, color: C.muted }}>{t.id}</span>
      </div>
      <h2 style={{ fontSize: 22, fontWeight: 900, margin: "0 0 4px" }}>{t.customer}</h2>
      <p style={{ color: C.muted, margin: "0 0 24px", fontSize: 13 }}>
        {t.currency} {t.amount.toLocaleString()} · {t.channel} · {t.location} · Risk: {(t.riskScore * 100).toFixed(0)}%
      </p>

      {stage === "loading" && (
        <div style={{ textAlign: "center", padding: "60px 0" }}>
          <div style={{ fontSize: 40, marginBottom: 16 }}>🤖</div>
          <div style={{ color: C.teal, fontWeight: 700, fontSize: 14 }}>AI Co-Pilot assembling case...</div>
          <div style={{ color: C.muted, fontSize: 12, marginTop: 6 }}>
            Retrieving transactions · KYC data · Policy library · Historical cases
          </div>
          <div style={{ marginTop: 20, display: "flex", gap: 8, justifyContent: "center" }}>
            {["Aggregating evidence","Querying RAG policy store","Generating summary","Drafting SAR"].map((s) => (
              <div key={s} style={{ padding: "4px 12px", borderRadius: 20, background: `${C.teal}10`, border: `1px solid ${C.teal}25`, fontSize: 10, color: C.teal }}>
                {s}
              </div>
            ))}
          </div>
        </div>
      )}

      {stage !== "loading" && (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
          {/* Left column */}
          <div>
            {/* Transaction details */}
            <div style={{ padding: "18px", borderRadius: 12, background: C.card, border: `1px solid ${C.border}`, marginBottom: 16 }}>
              <div style={{ fontSize: 10, color: C.muted, fontWeight: 700, letterSpacing: 1, marginBottom: 12 }}>
                TRANSACTION DETAILS
              </div>
              {([
                ["Transaction ID", t.id],
                ["Customer ID",    t.customerId],
                ["Amount",         `${t.currency} ${t.amount.toLocaleString()}`],
                ["Channel",        t.channel],
                ["Origin",         t.location + (HIGH_RISK_COUNTRIES.includes(t.location) ? " ⚠ HIGH-RISK" : "")],
                ["Typology",       t.type],
                ["Risk Score",     `${(t.riskScore * 100).toFixed(0)}%`],
              ] as [string, string][]).map(([l, v]) => (
                <div key={l} style={{ display: "flex", justifyContent: "space-between", padding: "6px 0", borderBottom: `1px solid ${C.border}`, fontSize: 12 }}>
                  <span style={{ color: C.muted }}>{l}</span>
                  <span style={{
                    color: l === "Risk Score"
                      ? getRiskColor(t.riskScore)
                      : l === "Origin" && HIGH_RISK_COUNTRIES.includes(t.location) ? C.red : C.text,
                    fontWeight: 600,
                  }}>
                    {v}
                  </span>
                </div>
              ))}
            </div>

            {/* AI Summary */}
            <div style={{ padding: "18px", borderRadius: 12, background: `${C.violet}08`, border: `1px solid ${C.violet}30` }}>
              <div style={{ fontSize: 10, color: C.violet, fontWeight: 700, letterSpacing: 1, marginBottom: 10 }}>
                🤖 AI CASE SUMMARY
              </div>
              <pre style={{ fontSize: 11, color: C.light, lineHeight: 1.7, whiteSpace: "pre-wrap", margin: 0, fontFamily: "inherit" }}>
                {summary}
              </pre>
            </div>

            {/* Investigator notes */}
            {stage !== "complete" && (
              <div style={{ marginTop: 16, padding: "16px", borderRadius: 12, background: C.card, border: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 10, color: C.muted, fontWeight: 700, letterSpacing: 1, marginBottom: 8 }}>
                  INVESTIGATOR NOTES
                </div>
                <textarea
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  rows={3}
                  placeholder="Add your investigation notes here..."
                  style={{
                    width: "100%", background: C.dim, border: `1px solid ${C.border}`,
                    borderRadius: 8, color: C.text, fontSize: 12, padding: "10px",
                    resize: "vertical", outline: "none", boxSizing: "border-box",
                  }}
                />
              </div>
            )}
          </div>

          {/* Right column */}
          <div>
            {/* SAR Draft */}
            <div style={{ padding: "18px", borderRadius: 12, background: `${C.teal}08`, border: `1px solid ${C.teal}30` }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <div style={{ fontSize: 10, color: C.teal, fontWeight: 700, letterSpacing: 1 }}>📄 AI-DRAFTED SAR — EDITABLE</div>
                <span style={{ fontSize: 9, color: C.orange, background: `${C.orange}15`, padding: "2px 8px", borderRadius: 10, border: `1px solid ${C.orange}30` }}>
                  REQUIRES HUMAN APPROVAL
                </span>
              </div>
              <textarea
                value={sarText}
                onChange={(e) => setSarText(e.target.value)}
                rows={18}
                style={{
                  width: "100%", background: C.dim, border: `1px solid ${C.border}`,
                  borderRadius: 8, color: C.text, fontSize: 11, padding: "12px",
                  resize: "vertical", outline: "none", lineHeight: 1.6,
                  boxSizing: "border-box", fontFamily: "monospace",
                }}
              />
            </div>

            {/* Decision panel */}
            {stage !== "complete" ? (
              <div style={{ marginTop: 16, padding: "18px", borderRadius: 12, background: C.card, border: `1px solid ${C.border}` }}>
                <div style={{ fontSize: 10, color: C.gold, fontWeight: 700, letterSpacing: 1, marginBottom: 10 }}>
                  👤 HUMAN DECISION — REQUIRED
                </div>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 12 }}>
                  This decision is yours alone. AI has provided analysis — you retain full authority. All decisions are permanently logged.
                </div>
                <textarea
                  value={justification}
                  onChange={(e) => setJustification(e.target.value)}
                  rows={2}
                  placeholder="Enter justification for your decision (required)..."
                  style={{
                    width: "100%", background: C.dim, border: `1px solid ${C.border}`,
                    borderRadius: 8, color: C.text, fontSize: 12, padding: "10px",
                    resize: "none", outline: "none", marginBottom: 12, boxSizing: "border-box",
                  }}
                />
                <div style={{ display: "flex", gap: 8 }}>
                  {([
                    { label: "✅ Approve SAR", action: "APPROVE",  color: C.green },
                    { label: "⬆️ Escalate",    action: "ESCALATE", color: C.orange },
                    { label: "✖️ Close Case",   action: "CLOSE",    color: C.muted },
                  ] as const).map((btn) => (
                    <button
                      key={btn.action}
                      onClick={() => handleDecision(btn.action)}
                      disabled={!justification.trim()}
                      style={{
                        flex: 1, padding: "10px 8px", borderRadius: 8,
                        border: `1px solid ${btn.color}40`,
                        background: justification.trim() ? `${btn.color}15` : "transparent",
                        color: justification.trim() ? btn.color : C.muted,
                        fontSize: 11, fontWeight: 700,
                        cursor: justification.trim() ? "pointer" : "not-allowed",
                      }}
                    >
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div style={{
                marginTop: 16, padding: "18px", borderRadius: 12,
                background: `${decision === "APPROVE" ? C.green : decision === "ESCALATE" ? C.orange : C.muted}10`,
                border: `1px solid ${decision === "APPROVE" ? C.green : decision === "ESCALATE" ? C.orange : C.muted}40`,
              }}>
                <div style={{
                  fontSize: 13, fontWeight: 800, marginBottom: 8,
                  color: decision === "APPROVE" ? C.green : decision === "ESCALATE" ? C.orange : C.light,
                }}>
                  {decision === "APPROVE" ? "✅ SAR Approved — Ready to File"
                    : decision === "ESCALATE" ? "⬆️ Case Escalated to Senior Review"
                    : "✖️ Case Closed"}
                </div>
                <div style={{ fontSize: 11, color: C.muted, marginBottom: 8 }}>
                  Justification recorded: "{justification}"
                </div>
                <div style={{ fontSize: 10, color: C.teal }}>
                  🔒 This decision has been immutably logged in the audit trail.
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
