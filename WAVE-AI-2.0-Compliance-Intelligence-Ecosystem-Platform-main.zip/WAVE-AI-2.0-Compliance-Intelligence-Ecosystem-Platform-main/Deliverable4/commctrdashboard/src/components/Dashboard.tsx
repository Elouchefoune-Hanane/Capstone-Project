import { C } from "../constants";
import { Transaction } from "../types";
import RiskBadge from "./RiskBadge";

interface Props {
  transactions: Transaction[];
  onNav: (view: string) => void;
}

export default function Dashboard({ transactions, onNav }: Props) {
  const open     = transactions.filter((t) => t.status === "OPEN");
  const critical = open.filter((t) => t.riskScore >= 0.85);
  const high     = open.filter((t) => t.riskScore >= 0.70 && t.riskScore < 0.85);

  return (
    <div style={{ padding: "28px 32px" }}>
      <div style={{ marginBottom: 28 }}>
        <div style={{ fontSize: 10, letterSpacing: 3, color: C.teal, fontWeight: 800, marginBottom: 6 }}>
          EXECUTIVE RISK COCKPIT
        </div>
        <h1 style={{ fontSize: 26, fontWeight: 900, margin: 0, letterSpacing: -0.5 }}>
          Compliance Intelligence Dashboard
        </h1>
        <p style={{ color: C.muted, margin: "4px 0 0", fontSize: 13 }}>
          Real-time overview — WAVE AI Compliance Command Center
        </p>
      </div>

      {/* KPI Row */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(5,1fr)", gap: 12, marginBottom: 24 }}>
        {[
          { label: "Total Transactions", value: transactions.length, sub: "Loaded from server",   color: C.blue },
          { label: "Open Alerts",        value: open.length,         sub: "Requires review",       color: C.orange },
          { label: "Critical Alerts",    value: critical.length,     sub: "Risk ≥ 85%",            color: C.red },
          { label: "High Alerts",        value: high.length,         sub: "Risk 70–84%",           color: C.gold },
          { label: "Closed / Low Risk",  value: transactions.length - open.length, sub: "Auto-filtered by AI", color: C.green },
        ].map((k, i) => (
          <div
            key={i}
            style={{
              padding: "18px 20px", borderRadius: 12,
              background: `${k.color}08`, border: `1px solid ${k.color}25`,
              textAlign: "center",
            }}
          >
            <div style={{ fontSize: 30, fontWeight: 900, color: k.color, lineHeight: 1 }}>{k.value}</div>
            <div style={{ fontSize: 11, fontWeight: 700, color: C.text, marginTop: 6 }}>{k.label}</div>
            <div style={{ fontSize: 10, color: C.muted, marginTop: 2 }}>{k.sub}</div>
          </div>
        ))}
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16 }}>
        {/* Critical */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.red, marginBottom: 10, letterSpacing: 1 }}>
            🔴 CRITICAL ALERTS — ACTION REQUIRED
          </div>
          {critical.slice(0, 4).map((t) => (
            <div
              key={t.id}
              onClick={() => onNav("alerts")}
              style={{
                padding: "12px 16px", borderRadius: 10, marginBottom: 8, cursor: "pointer",
                background: `${C.red}08`, border: `1px solid ${C.red}25`,
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}
            >
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{t.customer}</div>
                <div style={{ fontSize: 10, color: C.muted }}>
                  {t.currency} {t.amount.toLocaleString()} · {t.location} · {t.type}
                </div>
              </div>
              <RiskBadge score={t.riskScore} />
            </div>
          ))}
        </div>

        {/* High + readiness */}
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: C.orange, marginBottom: 10, letterSpacing: 1 }}>
            🟠 HIGH RISK ALERTS
          </div>
          {high.slice(0, 4).map((t) => (
            <div
              key={t.id}
              onClick={() => onNav("alerts")}
              style={{
                padding: "12px 16px", borderRadius: 10, marginBottom: 8, cursor: "pointer",
                background: `${C.orange}08`, border: `1px solid ${C.orange}25`,
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}
            >
              <div>
                <div style={{ fontSize: 12, fontWeight: 700, color: C.text }}>{t.customer}</div>
                <div style={{ fontSize: 10, color: C.muted }}>
                  {t.currency} {t.amount.toLocaleString()} · {t.location} · {t.type}
                </div>
              </div>
              <RiskBadge score={t.riskScore} />
            </div>
          ))}

          <div style={{
            marginTop: 16, padding: "16px", borderRadius: 12,
            background: `${C.teal}08`, border: `1px solid ${C.teal}25`,
          }}>
            <div style={{ fontSize: 10, color: C.teal, fontWeight: 700, marginBottom: 8 }}>
              REGULATORY READINESS SCORE
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
              <div style={{ fontSize: 28, fontWeight: 900, color: C.teal }}>84%</div>
              <div>
                <div style={{ fontSize: 11, color: C.text }}>AML Controls Active</div>
                <div style={{ fontSize: 10, color: C.muted }}>
                  2 policy gaps identified — remediation pending
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
