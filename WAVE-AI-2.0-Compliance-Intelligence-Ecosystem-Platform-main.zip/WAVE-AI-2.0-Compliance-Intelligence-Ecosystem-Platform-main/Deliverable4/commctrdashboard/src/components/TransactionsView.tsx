import { useState } from "react";
import { C, HIGH_RISK_COUNTRIES, CURRENCIES, CHANNELS, ALL_COUNTRIES } from "../constants";
import { Transaction, TransactionForm } from "../types";
import { getRiskColor } from "../utils";
import { scoreTransaction } from "../api";
import RiskBadge from "./RiskBadge";

interface Props {
  onSubmit: (txn: Transaction) => void;
}

export default function TransactionsView({ onSubmit }: Props) {
  const [form, setForm] = useState<TransactionForm>({
    customer: "",
    amount: "",
    currency: "USD",
    channel: "ONLINE",
    location: "USA",
  });
  const [result, setResult]   = useState<Transaction | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError]     = useState<string | null>(null);

  async function handleSubmit() {
    if (!form.customer || !form.amount) return;
    setLoading(true);
    setError(null);
    try {
      const { transaction } = await scoreTransaction(form);
      setResult(transaction);
      if (transaction.riskScore >= 0.7) onSubmit(transaction);
    } catch {
      setError("Server unavailable — ensure the backend is running on port 3001.");
    } finally {
      setLoading(false);
    }
  }

  function updateField(key: keyof TransactionForm, value: string) {
    setForm((prev) => ({ ...prev, [key]: value }));
  }

  return (
    <div style={{ padding: "28px 32px" }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: C.blue, fontWeight: 800, marginBottom: 6 }}>
        TRANSACTION INTAKE
      </div>
      <h2 style={{ fontSize: 24, fontWeight: 900, margin: "0 0 4px" }}>Submit New Transaction</h2>
      <p style={{ color: C.muted, margin: "0 0 24px", fontSize: 13 }}>
        AI fraud model scores in real-time. Alert auto-created if risk ≥ 70%.
      </p>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 24 }}>
        {/* Form */}
        <div style={{ padding: "24px", borderRadius: 14, background: C.card, border: `1px solid ${C.border}` }}>
          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            {(["customer", "amount"] as const).map((key) => (
              <div key={key}>
                <label style={{ fontSize: 10, color: C.muted, fontWeight: 700, letterSpacing: 1, display: "block", marginBottom: 6 }}>
                  {key === "customer" ? "CUSTOMER NAME" : "TRANSACTION AMOUNT"}
                </label>
                <input
                  type={key === "amount" ? "number" : "text"}
                  placeholder={key === "customer" ? "Full legal name" : "e.g. 15000"}
                  value={form[key]}
                  onChange={(e) => updateField(key, e.target.value)}
                  style={{
                    width: "100%", padding: "10px 14px", borderRadius: 8,
                    background: C.dim, border: `1px solid ${C.border}`,
                    color: C.text, fontSize: 13, outline: "none", boxSizing: "border-box",
                  }}
                />
              </div>
            ))}

            <div>
              <label style={{ fontSize: 10, color: C.muted, fontWeight: 700, letterSpacing: 1, display: "block", marginBottom: 6 }}>
                CURRENCY
              </label>
              <select
                value={form.currency}
                onChange={(e) => updateField("currency", e.target.value)}
                style={{
                  width: "100%", padding: "10px 14px", borderRadius: 8,
                  background: C.dim, border: `1px solid ${C.border}`,
                  color: C.text, fontSize: 13, outline: "none",
                }}
              >
                {CURRENCIES.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label style={{ fontSize: 10, color: C.muted, fontWeight: 700, letterSpacing: 1, display: "block", marginBottom: 6 }}>
                CHANNEL
              </label>
              <select
                value={form.channel}
                onChange={(e) => updateField("channel", e.target.value)}
                style={{
                  width: "100%", padding: "10px 14px", borderRadius: 8,
                  background: C.dim, border: `1px solid ${C.border}`,
                  color: C.text, fontSize: 13, outline: "none",
                }}
              >
                {CHANNELS.map((c) => <option key={c}>{c}</option>)}
              </select>
            </div>

            <div>
              <label style={{ fontSize: 10, color: C.muted, fontWeight: 700, letterSpacing: 1, display: "block", marginBottom: 6 }}>
                ORIGIN LOCATION
              </label>
              <select
                value={form.location}
                onChange={(e) => updateField("location", e.target.value)}
                style={{
                  width: "100%", padding: "10px 14px", borderRadius: 8,
                  background: C.dim, border: `1px solid ${C.border}`,
                  color: C.text, fontSize: 13, outline: "none",
                }}
              >
                {ALL_COUNTRIES.map((l) => (
                  <option key={l} value={l}>{l}</option>
                ))}
              </select>
              {HIGH_RISK_COUNTRIES.includes(form.location) && (
                <div style={{ marginTop: 6, fontSize: 10, color: C.red }}>⚠ High-risk jurisdiction detected</div>
              )}
            </div>

            {error && (
              <div style={{ padding: "10px 14px", borderRadius: 8, background: `${C.red}10`, border: `1px solid ${C.red}30`, fontSize: 11, color: C.red }}>
                {error}
              </div>
            )}

            <button
              onClick={handleSubmit}
              disabled={loading}
              style={{
                padding: "12px", borderRadius: 10, border: "none",
                cursor: loading ? "wait" : "pointer",
                background: loading ? C.muted : `linear-gradient(135deg,${C.teal},${C.violet})`,
                color: C.bg, fontWeight: 800, fontSize: 13, letterSpacing: 0.5,
                transition: "opacity 0.2s",
              }}
            >
              {loading ? "⚡ AI Scoring..." : "Submit Transaction →"}
            </button>
          </div>
        </div>

        {/* Result */}
        <div>
          {!result ? (
            <div style={{
              height: "100%", borderRadius: 14, border: `1px dashed ${C.border}`,
              display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center",
              color: C.muted, fontSize: 13, gap: 8,
            }}>
              <div style={{ fontSize: 32 }}>⚡</div>
              <div>AI fraud score appears here instantly</div>
            </div>
          ) : (
            <div style={{
              borderRadius: 14, background: C.card,
              border: `1px solid ${getRiskColor(result.riskScore)}40`,
              padding: "24px", height: "100%", boxSizing: "border-box",
            }}>
              <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: C.text }}>Fraud Scoring Result</div>
                <RiskBadge score={result.riskScore} />
              </div>

              <div style={{ marginBottom: 20 }}>
                <div style={{ fontSize: 10, color: C.muted, marginBottom: 6 }}>COMPOSITE RISK SCORE</div>
                <div style={{ height: 10, borderRadius: 5, background: C.dim, overflow: "hidden" }}>
                  <div style={{
                    height: "100%", width: `${result.riskScore * 100}%`,
                    background: `linear-gradient(90deg,${C.teal},${getRiskColor(result.riskScore)})`,
                    borderRadius: 5, transition: "width 0.8s ease",
                  }} />
                </div>
                <div style={{ fontSize: 28, fontWeight: 900, color: getRiskColor(result.riskScore), marginTop: 6 }}>
                  {(result.riskScore * 100).toFixed(0)}%
                </div>
              </div>

              {([
                ["Transaction ID", result.id],
                ["Customer",       result.customer],
                ["Amount",         `${result.currency} ${Number(result.amount).toLocaleString()}`],
                ["Channel",        result.channel],
                ["Location",       result.location],
                ["Alert Created",  result.riskScore >= 0.7 ? "✅ Yes — Open in Alerts" : "❌ No — Low risk, auto-closed"],
              ] as [string, string][]).map(([l, v]) => (
                <div key={l} style={{
                  display: "flex", justifyContent: "space-between",
                  padding: "8px 0", borderBottom: `1px solid ${C.border}`, fontSize: 12,
                }}>
                  <span style={{ color: C.muted }}>{l}</span>
                  <span style={{ color: l === "Alert Created" && result.riskScore >= 0.7 ? C.green : C.text, fontWeight: 600 }}>
                    {v}
                  </span>
                </div>
              ))}

              <div style={{
                marginTop: 16, padding: "10px 14px", borderRadius: 8,
                background: `${C.teal}08`, border: `1px solid ${C.teal}20`,
                fontSize: 11, color: C.muted,
              }}>
                <strong style={{ color: C.teal }}>SHAP Explanation: </strong>
                Score driven by:{" "}
                {result.riskScore >= 0.7
                  ? `amount (${Number(result.amount) > 9000 && Number(result.amount) < 10000 ? "structuring pattern" : "high value"}), ${HIGH_RISK_COUNTRIES.includes(result.location) ? "high-risk jurisdiction, " : ""}channel type`
                  : "all factors within normal range"}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
