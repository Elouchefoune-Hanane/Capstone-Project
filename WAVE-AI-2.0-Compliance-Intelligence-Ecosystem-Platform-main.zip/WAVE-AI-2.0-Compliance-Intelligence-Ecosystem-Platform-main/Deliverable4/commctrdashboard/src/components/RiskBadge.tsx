import { C } from "../constants";
import { getRiskColor, getRiskLabel } from "../utils";

export default function RiskBadge({ score }: { score: number }) {
  const color = getRiskColor(score);
  return (
    <span
      style={{
        fontSize: 9,
        fontWeight: 800,
        letterSpacing: 1.5,
        padding: "3px 8px",
        borderRadius: 20,
        color,
        border: `1px solid ${color}50`,
        background: `${color}15`,
      }}
    >
      {getRiskLabel(score)}
    </span>
  );
}
