import { useState } from "react";
import { C, HIGH_RISK_COUNTRIES } from "../constants";
import { Transaction } from "../types";
import { getRiskColor, getRiskLabel } from "../utils";
import RiskBadge from "./RiskBadge";

interface Props {
  transactions: Transaction[];
  onInvestigate: (txn: Transaction) => void;
}

export default function AlertsView({ transactions, onInvestigate }: Props) {
  const [filter, setFilter] = useState("ALL");

  const open     = transactions.filter((t) => t.status === "OPEN");
  const filtered = filter === "ALL" ? open : open.filter((t) => getRiskLabel(t.riskScore) === filter);

  return (
    <div style={{ padding: "28px 32px" }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: C.orange, fontWeight: 800, marginBottom: 6 }}>
        ALERT QUEUE
      </div>
      <h2 style={{ fontSize: 24, fontWeight: 900, margin: "0 0 4px" }}>Open Alerts — AI Prioritized</h2>
      <p style={{ color: C.muted, margin: "0 0 20px", fontSize: 13 }}>
        AI has ranked and prioritised {open.length} alerts. High-risk alerts appear first. Click any alert to open
        the Investigator Co-Pilot.
      </p>

      <div style={{ display: "flex", gap: 8, marginBottom: 20 }}>
        {(["ALL", "CRITICAL", "HIGH", "MEDIUM"] as const).map((f) => {
          const active = filter === f;
          const color  = f === "CRITICAL" ? C.red : f === "HIGH" ? C.orange : f === "MEDIUM" ? C.gold : C.teal;
          const count  = f !== "ALL" ? open.filter((t) => getRiskLabel(t.riskScore) === f).length : null;
          return (
            <button
              key={f}
              onClick={() => setFilter(f)}
              style={{
                padding: "6px 16px", borderRadius: 8, cursor: "pointer", fontSize: 11, fontWeight: 700,
                background: active ? `${color}20` : "transparent",
                border: `1px solid ${active ? color + "60" : C.border}`,
                color: active ? color : C.muted,
              }}
            >
              {f} {count !== null && `(${count})`}
            </button>
          );
        })}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {[...filtered].sort((a, b) => b.riskScore - a.riskScore).map((t) => (
          <div
            key={t.id}
            onClick={() => onInvestigate(t)}
            onMouseEnter={(e) => (e.currentTarget.style.borderColor = getRiskColor(t.riskScore) + "50")}
            onMouseLeave={(e) => (e.currentTarget.style.borderColor = C.border)}
            style={{
              padding: "16px 20px", borderRadius: 12, cursor: "pointer",
              background: C.card, border: `1px solid ${C.border}`,
              display: "flex", alignItems: "center", gap: 16,
              transition: "border-color 0.2s",
            }}
          >
            <div style={{
              width: 52, height: 52, borderRadius: "50%", flexShrink: 0,
              background: `${getRiskColor(t.riskScore)}15`,
              border: `2px solid ${getRiskColor(t.riskScore)}50`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 13, fontWeight: 900, color: getRiskColor(t.riskScore),
            }}>
              {(t.riskScore * 100).toFixed(0)}%
            </div>

            <div style={{ flex: 1 }}>
              <div style={{ display: "flex", alignItems: "center", gap: 10, marginBottom: 4 }}>
                <span style={{ fontSize: 14, fontWeight: 800, color: C.text }}>{t.customer}</span>
                <RiskBadge score={t.riskScore} />
                <span style={{ fontSize: 10, color: C.muted, background: C.dim, padding: "2px 8px", borderRadius: 10 }}>
                  {t.type}
                </span>
              </div>
              <div style={{ fontSize: 12, color: C.muted }}>
                {t.id} · {t.currency} {t.amount.toLocaleString()} · {t.channel} · {t.location}
                {HIGH_RISK_COUNTRIES.includes(t.location) && (
                  <span style={{ color: C.red, marginLeft: 6 }}>⚠ High-Risk Jurisdiction</span>
                )}
              </div>
            </div>

            <button style={{
              padding: "8px 16px", borderRadius: 8, border: `1px solid ${C.teal}40`,
              background: `${C.teal}10`, color: C.teal, fontSize: 11, fontWeight: 700, cursor: "pointer",
            }}>
              Investigate →
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}
