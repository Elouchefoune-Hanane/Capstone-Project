import { useState, useEffect } from "react";
import { C } from "../constants";
import { AuditEntry } from "../types";
import { getAuditLog } from "../api";

interface Props {
  refresh: number;
}

export default function AuditView({ refresh }: Props) {
  const [auditLog, setAuditLog] = useState<AuditEntry[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    setLoading(true);
    getAuditLog()
      .then(setAuditLog)
      .catch(() => setAuditLog([]))
      .finally(() => setLoading(false));
  }, [refresh]);

  return (
    <div style={{ padding: "28px 32px" }}>
      <div style={{ fontSize: 10, letterSpacing: 3, color: C.gold, fontWeight: 800, marginBottom: 6 }}>
        GOVERNANCE & ACCOUNTABILITY
      </div>
      <h2 style={{ fontSize: 24, fontWeight: 900, margin: "0 0 4px" }}>Immutable Audit Trail</h2>
      <p style={{ color: C.muted, margin: "0 0 24px", fontSize: 13 }}>
        Every AI action, human decision, and override — permanently logged. Regulators can query in seconds.
      </p>

      {loading ? (
        <div style={{ textAlign: "center", padding: "60px 0", color: C.muted, fontSize: 13 }}>
          Loading audit log...
        </div>
      ) : auditLog.length === 0 ? (
        <div style={{ textAlign: "center", padding: "60px 0", color: C.muted, fontSize: 13 }}>
          <div style={{ fontSize: 32, marginBottom: 12 }}>📋</div>
          <div>No activity logged yet. Submit a transaction or investigate an alert to see the audit trail.</div>
        </div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {auditLog.map((log) => {
            const isSar   = log.action.includes("SAR");
            const isClose = log.action.includes("CLOSE");
            const isAi    = log.action.includes("AI") || log.action.includes("CASE");
            const iconBg  = isSar ? `${C.green}15` : isClose ? `${C.muted}15` : isAi ? `${C.violet}15` : `${C.teal}15`;
            const iconBorder = isSar ? C.green : isAi ? C.violet : C.teal;
            const icon    = isSar ? "✅" : isClose ? "✖️" : isAi ? "🤖" : "📋";

            return (
              <div
                key={log.id}
                style={{
                  padding: "14px 18px", borderRadius: 10,
                  background: C.card, border: `1px solid ${C.border}`,
                  display: "flex", gap: 16, alignItems: "flex-start",
                }}
              >
                <div style={{
                  width: 32, height: 32, borderRadius: 8, flexShrink: 0,
                  background: iconBg, border: `1px solid ${iconBorder}30`,
                  display: "flex", alignItems: "center", justifyContent: "center", fontSize: 14,
                }}>
                  {icon}
                </div>
                <div style={{ flex: 1 }}>
                  <div style={{ display: "flex", gap: 10, alignItems: "center", marginBottom: 4 }}>
                    <span style={{ fontSize: 12, fontWeight: 700, color: C.text }}>
                      {log.action.replace(/_/g, " ")}
                    </span>
                    <span style={{ fontSize: 10, color: C.muted, background: C.dim, padding: "2px 8px", borderRadius: 10 }}>
                      {log.user}
                    </span>
                    <span style={{ fontSize: 10, color: C.muted }}>{log.ts}</span>
                  </div>
                  <div style={{ fontSize: 11, color: C.muted }}>
                    Entity: <strong style={{ color: C.light }}>{log.entity}</strong> — {log.detail}
                  </div>
                </div>
                <div style={{ fontSize: 9, color: C.teal, letterSpacing: 1, fontWeight: 700 }}>IMMUTABLE</div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
