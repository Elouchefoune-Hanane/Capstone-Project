import { C } from "./constants";

export function getRiskColor(score: number): string {
  if (score >= 0.85) return C.red;
  if (score >= 0.70) return C.orange;
  if (score >= 0.50) return C.gold;
  return C.green;
}

export function getRiskLabel(score: number): string {
  if (score >= 0.85) return "CRITICAL";
  if (score >= 0.70) return "HIGH";
  if (score >= 0.50) return "MEDIUM";
  return "LOW";
}
