// Re-exports the refactored App from src/.
// All logic, components, and types now live under src/.
export { default } from "./src/App";
