# WAVE AI — Compliance Command Center
https://claude.ai/public/artifacts/c3346536-cbde-4a45-9431-000dde3d6f38

AI-assisted AML compliance tool for financial investigators. Flags suspicious transactions, generates SAR drafts, and maintains an immutable audit trail — with humans retaining all final decision authority.

---

## Project Structure

```
Deliverable4/
├── commctrdashboard/   # React + TypeScript frontend (Vite)
│   ├── src/
│   │   ├── components/ # Dashboard, Alerts, Investigator, Audit, Transactions
│   │   ├── App.tsx
│   │   ├── api.ts      # Typed fetch wrappers
│   │   ├── constants.ts
│   │   ├── types.ts
│   │   └── utils.ts
│   └── compliancecommctr.tsx
└── server/             # Express backend
    └── server.js
```

---

## Features

| View | Description |
|---|---|
| **Dashboard** | KPI overview — open alerts, critical/high counts, regulatory readiness score |
| **Transactions** | Submit a transaction; AI risk model scores it in real-time |
| **Alerts** | Prioritized queue of open alerts filtered by risk level |
| **Investigator Co-Pilot** | AI-generated case summary + editable SAR draft; human approves/escalates/closes |
| **Audit Trail** | Immutable log of every AI action and human decision |

---

## Getting Started

### Prerequisites
- Node.js 18+

### 1. Backend

```bash
cd server
cp .env.example .env
npm install
npm start
```

Runs on `http://localhost:3001`

### 2. Frontend

```bash
cd commctrdashboard
cp .env.example .env
npm install
npm run dev
```

Runs on `http://localhost:3000`

---

## Environment Variables

**`commctrdashboard/.env`**
```
VITE_API_BASE=http://localhost:3001/api
```

**`server/.env`**
```
PORT=3001
```

---

## API Endpoints

| Method | Route | Description |
|---|---|---|
| `GET` | `/api/transactions` | List all transactions |
| `POST` | `/api/transactions/score` | Score a new transaction |
| `GET` | `/api/audit` | Fetch audit log |
| `POST` | `/api/audit` | Append audit entry |
| `POST` | `/api/sar` | Generate SAR draft for a transaction |
| `POST` | `/api/summary` | Generate AI case summary for a transaction |

---

## Tech Stack

- **Frontend:** React 18, TypeScript, Vite
- **Backend:** Node.js, Express, dotenv
- **Styling:** Inline styles with design token system

---

*WIC × Microsoft AI Innovator Apprenticeship · 2026*
