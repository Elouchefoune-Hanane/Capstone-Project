import { GlossaryData } from "../types";

const API_BASE = import.meta.env.VITE_API_URL ?? "http://localhost:4002";

export async function fetchGlossary(): Promise<GlossaryData> {
  const res = await fetch(`${API_BASE}/api/glossary`);
  if (!res.ok) {
    throw new Error(`Request to /api/glossary failed with status ${res.status}`);
  }
  return res.json() as Promise<GlossaryData>;
}
