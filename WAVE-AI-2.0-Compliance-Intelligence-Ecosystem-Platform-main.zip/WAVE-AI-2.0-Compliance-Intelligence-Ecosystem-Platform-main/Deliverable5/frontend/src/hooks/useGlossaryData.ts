import { useEffect, useState } from "react";
import { fetchGlossary } from "../api/client";
import { GlossaryData } from "../types";

interface GlossaryDataState {
  data: GlossaryData | null;
  loading: boolean;
  error: string | null;
}

export function useGlossaryData(): GlossaryDataState {
  const [state, setState] = useState<GlossaryDataState>({
    data: null,
    loading: true,
    error: null,
  });

  useEffect(() => {
    let cancelled = false;

    fetchGlossary()
      .then((data) => {
        if (!cancelled) setState({ data, loading: false, error: null });
      })
      .catch((err: Error) => {
        if (!cancelled) setState({ data: null, loading: false, error: err.message });
      });

    return () => {
      cancelled = true;
    };
  }, []);

  return state;
}
