import AcronymGlossary from "./components/acronymglossary";

export default function App() {
  return <AcronymGlossary />;
}
