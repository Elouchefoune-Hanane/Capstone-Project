export interface GlossaryTerm {
  term: string;
  full: string;
  cat: string;
  plain: string;
  example: string;
}

export interface GlossaryData {
  categories: string[];
  terms: GlossaryTerm[];
}
