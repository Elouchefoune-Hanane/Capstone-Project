import { useState } from "react";
import { useGlossaryData } from "../hooks/useGlossaryData";
import type { GlossaryTerm } from "../types";

const CAT_COLORS: Record<string, string> = {
  "AI & Technology": "#00E5C8",
  "Compliance & Regulation": "#38BDF8",
  "Financial Crime": "#F43F5E",
  "Architecture & Systems": "#A78BFA",
  "Project & Team": "#FACC15",
  "Governance & Risk": "#F97316",
};

type View = "cards" | "table";

export default function AcronymGlossary() {
  const { data, loading, error } = useGlossaryData();
  const [search, setSearch] = useState("");
  const [cat, setCat] = useState("All");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [view, setView] = useState<View>("cards");

  if (loading) {
    return (
      <div style={{
        minHeight: "100vh", background: "#06080F", color: "#64748B",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "'DM Sans','Segoe UI',sans-serif", fontSize: 14,
      }}>
        Loading glossary…
      </div>
    );
  }

  if (error || !data) {
    return (
      <div style={{
        minHeight: "100vh", background: "#06080F", color: "#F43F5E",
        display: "flex", alignItems: "center", justifyContent: "center",
        fontFamily: "'DM Sans','Segoe UI',sans-serif", fontSize: 14,
      }}>
        Failed to load glossary{error ? `: ${error}` : ""}
      </div>
    );
  }

  const { categories, terms } = data;

  const filtered = terms.filter(t => {
    const q = search.toLowerCase();
    const matchSearch = !q ||
      t.term.toLowerCase().includes(q) ||
      t.full.toLowerCase().includes(q) ||
      t.plain.toLowerCase().includes(q);
    const matchCat = cat === "All" || t.cat === cat;
    return matchSearch && matchCat;
  });

  const grouped = categories.slice(1).reduce<Record<string, GlossaryTerm[]>>((acc, c) => {
    acc[c] = filtered.filter(t => t.cat === c);
    return acc;
  }, {});

  return (
    <div style={{
      minHeight:"100vh",
      background:"#06080F",
      color:"#E2E8F0",
      fontFamily:"'DM Sans','Segoe UI',sans-serif",
    }}>

      {/* ── HEADER ── */}
      <div style={{
        background:"#0D1117",
        borderBottom:"1px solid rgba(255,255,255,0.07)",
        padding:"28px 40px 24px",
      }}>
        <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", flexWrap:"wrap", gap:16 }}>
          <div>
            <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:8 }}>
              <div style={{
                width:36, height:36, borderRadius:8,
                background:"linear-gradient(135deg,#00E5C8,#A78BFA)",
                display:"flex", alignItems:"center", justifyContent:"center",
                fontSize:18,
              }}>📖</div>
              <span style={{ fontSize:10, letterSpacing:3, color:"#00E5C8", fontWeight:800 }}>
                WAVE AI · REFERENCE DOCUMENT
              </span>
            </div>
            <h1 style={{ margin:0, fontSize:26, fontWeight:800, letterSpacing:-0.5 }}>
              Acronyms & Glossary
            </h1>
            <p style={{ margin:"6px 0 0", color:"#64748B", fontSize:14 }}>
              Plain-English definitions for every term used in the WAVE AI Compliance Command Center project
            </p>
          </div>
          <div style={{ display:"flex", gap:10, alignItems:"center", flexWrap:"wrap" }}>
            <div style={{
              background:"rgba(0,229,200,0.08)", border:"1px solid rgba(0,229,200,0.25)",
              borderRadius:10, padding:"8px 16px", textAlign:"center",
            }}>
              <div style={{ fontSize:22, fontWeight:800, color:"#00E5C8" }}>{terms.length}</div>
              <div style={{ fontSize:10, color:"#64748B" }}>Total Terms</div>
            </div>
            <div style={{
              background:"rgba(167,139,250,0.08)", border:"1px solid rgba(167,139,250,0.25)",
              borderRadius:10, padding:"8px 16px", textAlign:"center",
            }}>
              <div style={{ fontSize:22, fontWeight:800, color:"#A78BFA" }}>{categories.length - 1}</div>
              <div style={{ fontSize:10, color:"#64748B" }}>Categories</div>
            </div>
            {/* View toggle */}
            <div style={{ display:"flex", border:"1px solid rgba(255,255,255,0.1)", borderRadius:8, overflow:"hidden" }}>
              {(["cards","table"] as View[]).map(v=>(
                <button key={v} onClick={()=>setView(v)} style={{
                  padding:"8px 14px", cursor:"pointer", fontSize:11, fontWeight:600,
                  background: view===v ? "rgba(0,229,200,0.15)" : "transparent",
                  color: view===v ? "#00E5C8" : "#64748B",
                  border:"none", textTransform:"capitalize",
                }}>{v==="cards"?"🃏 Cards":"📋 Table"}</button>
              ))}
            </div>
          </div>
        </div>

        {/* Search + filter */}
        <div style={{ display:"flex", gap:12, marginTop:20, flexWrap:"wrap" }}>
          <div style={{ position:"relative", flex:1, minWidth:200 }}>
            <span style={{ position:"absolute", left:12, top:"50%", transform:"translateY(-50%)", color:"#64748B", fontSize:14 }}>🔍</span>
            <input
              value={search} onChange={e=>setSearch(e.target.value)}
              placeholder="Search any term, acronym, or keyword…"
              style={{
                width:"100%", padding:"10px 12px 10px 36px",
                background:"#111827", border:"1px solid rgba(255,255,255,0.1)",
                borderRadius:10, color:"#E2E8F0", fontSize:13, outline:"none",
                boxSizing:"border-box",
              }}
            />
          </div>
          <div style={{ display:"flex", gap:6, flexWrap:"wrap" }}>
            {categories.map(c=>(
              <button key={c} onClick={()=>setCat(c)} style={{
                padding:"8px 14px", borderRadius:8, cursor:"pointer",
                fontSize:11, fontWeight:600, transition:"all 0.15s",
                background: cat===c ? `${CAT_COLORS[c] || "#00E5C8"}18` : "transparent",
                border:`1px solid ${cat===c ? (CAT_COLORS[c]||"#00E5C8")+"60" : "rgba(255,255,255,0.08)"}`,
                color: cat===c ? (CAT_COLORS[c]||"#00E5C8") : "#64748B",
              }}>{c}</button>
            ))}
          </div>
        </div>
      </div>

      {/* ── CONTENT ── */}
      <div style={{ padding:"28px 40px" }}>

        {filtered.length === 0 && (
          <div style={{ textAlign:"center", color:"#64748B", padding:"60px 0", fontSize:14 }}>
            No terms match your search. Try a different keyword.
          </div>
        )}

        {view === "table" ? (
          /* ── TABLE VIEW ── */
          <div style={{ overflowX:"auto" }}>
            <table style={{ width:"100%", borderCollapse:"collapse", fontSize:12 }}>
              <thead>
                <tr style={{ borderBottom:"1px solid rgba(255,255,255,0.1)" }}>
                  {["Acronym","Full Name","Category","Plain-English Meaning","Real Example"].map(h=>(
                    <th key={h} style={{
                      padding:"10px 14px", textAlign:"left",
                      fontSize:10, letterSpacing:1.5, fontWeight:800,
                      color:"#64748B", textTransform:"uppercase",
                    }}>{h}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map((t,i)=>(
                  <tr key={i} style={{
                    borderBottom:"1px solid rgba(255,255,255,0.04)",
                    background: i%2===0 ? "rgba(255,255,255,0.01)" : "transparent",
                  }}>
                    <td style={{ padding:"12px 14px", fontWeight:800, color:CAT_COLORS[t.cat]||"#00E5C8", fontSize:13, whiteSpace:"nowrap" }}>{t.term}</td>
                    <td style={{ padding:"12px 14px", color:"#C8D4E8", fontWeight:600, minWidth:160 }}>{t.full}</td>
                    <td style={{ padding:"12px 14px", whiteSpace:"nowrap" }}>
                      <span style={{
                        fontSize:9, fontWeight:700, letterSpacing:1,
                        padding:"2px 8px", borderRadius:10,
                        color:CAT_COLORS[t.cat], border:`1px solid ${CAT_COLORS[t.cat]}40`,
                        background:`${CAT_COLORS[t.cat]}10`,
                      }}>{t.cat}</span>
                    </td>
                    <td style={{ padding:"12px 14px", color:"#94A3B8", lineHeight:1.6, minWidth:260 }}>{t.plain}</td>
                    <td style={{ padding:"12px 14px", color:"#64748B", lineHeight:1.6, fontStyle:"italic", minWidth:240 }}>{t.example}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          /* ── CARDS VIEW ── */
          <div>
            {(cat === "All" ? categories.slice(1) : [cat]).map(c=>{
              const items = cat === "All" ? grouped[c] : filtered;
              if (!items || items.length === 0) return null;
              return (
                <div key={c} style={{ marginBottom:36 }}>
                  <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:14 }}>
                    <div style={{ flex:1, height:1, background:`${CAT_COLORS[c]}30` }}/>
                    <span style={{
                      fontSize:10, letterSpacing:2.5, fontWeight:800,
                      color:CAT_COLORS[c], textTransform:"uppercase",
                      padding:"4px 14px", borderRadius:20,
                      background:`${CAT_COLORS[c]}10`, border:`1px solid ${CAT_COLORS[c]}30`,
                    }}>{c} — {items.length} terms</span>
                    <div style={{ flex:1, height:1, background:`${CAT_COLORS[c]}30` }}/>
                  </div>

                  <div style={{ display:"grid", gridTemplateColumns:"repeat(auto-fill,minmax(340px,1fr))", gap:12 }}>
                    {items.map((t,i)=>{
                      const key = `${c}-${i}`;
                      const open = expanded === key;
                      return (
                        <div key={key} onClick={()=>setExpanded(open?null:key)} style={{
                          background: open ? `${CAT_COLORS[c]}08` : "#111827",
                          border:`1px solid ${open ? CAT_COLORS[c]+"60" : "rgba(255,255,255,0.07)"}`,
                          borderRadius:12, padding:"16px 18px", cursor:"pointer",
                          transition:"all 0.2s",
                        }}>
                          <div style={{ display:"flex", alignItems:"flex-start", justifyContent:"space-between", gap:8 }}>
                            <div style={{ flex:1 }}>
                              <div style={{ display:"flex", alignItems:"center", gap:10, marginBottom:5 }}>
                                <span style={{
                                  fontSize:16, fontWeight:900, color:CAT_COLORS[c],
                                  fontFamily:"monospace", letterSpacing:-0.5,
                                }}>{t.term}</span>
                                <span style={{ fontSize:11, color:"#94A3B8", fontWeight:600 }}>{t.full}</span>
                              </div>
                              <p style={{ margin:0, fontSize:12, color:"#94A3B8", lineHeight:1.65 }}>
                                {t.plain}
                              </p>
                            </div>
                            <div style={{
                              width:22, height:22, borderRadius:"50%", flexShrink:0,
                              border:`1px solid ${CAT_COLORS[c]}40`,
                              display:"flex", alignItems:"center", justifyContent:"center",
                              color:CAT_COLORS[c], fontSize:13,
                              transition:"transform 0.2s",
                              transform: open ? "rotate(45deg)" : "none",
                            }}>+</div>
                          </div>

                          {open && (
                            <div style={{
                              marginTop:14, padding:"12px 14px", borderRadius:8,
                              background:`${CAT_COLORS[c]}10`, border:`1px solid ${CAT_COLORS[c]}25`,
                            }}>
                              <div style={{ fontSize:9, letterSpacing:2, color:CAT_COLORS[c], fontWeight:700, marginBottom:6 }}>
                                REAL-WORLD EXAMPLE
                              </div>
                              <p style={{ margin:0, fontSize:12, color:"#CBD5E1", lineHeight:1.7, fontStyle:"italic" }}>
                                "{t.example}"
                              </p>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* ── FOOTER ── */}
      <div style={{
        borderTop:"1px solid rgba(255,255,255,0.05)",
        padding:"16px 40px",
        display:"flex", justifyContent:"space-between", alignItems:"center",
        color:"#374151", fontSize:11, letterSpacing:0.5,
      }}>
        <span>WAVE AI COMPLIANCE COMMAND CENTER · ACRONYMS & GLOSSARY</span>
        <span>WIC × MICROSOFT AI INNOVATOR APPRENTICESHIP · 2026</span>
      </div>
    </div>
  );
}
