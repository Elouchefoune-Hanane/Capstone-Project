# Deliverable 5 — Acronyms & Glossary Reference

https://claude.ai/public/artifacts/bae78973-b912-42c9-9e1f-a5cbe84c0fd0

> Plain-English reference tool for the **WIC × Microsoft AI Innovator Apprenticeship (2026)**

Searchable, filterable glossary of every acronym and term used across the WAVE AI Compliance Command Center project — covering AI & technology, compliance & regulation, financial crime, architecture, project/team, and governance & risk categories.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Frontend | React 18, TypeScript 5, Vite 7 |
| Backend | Node.js (ESM), Express 4, TypeScript 5 |
| Dev tooling | tsx, TypeScript compiler, Vite |

---

## Project Structure

```
Deliverable5/
├── backend/                      # Express.js REST API
│   ├── src/
│   │   ├── index.ts              # Server entry point
│   │   ├── types.ts              # Type definitions
│   │   ├── routes/
│   │   │   └── glossary.ts       # /api/glossary route
│   │   └── data/
│   │       └── terms.ts          # Categories + glossary terms
│   ├── package.json
│   └── tsconfig.json
│
├── frontend/                      # React + Vite frontend
│   ├── src/
│   │   ├── App.tsx                # Root component
│   │   ├── types.ts               # Frontend types
│   │   ├── api/
│   │   │   └── client.ts          # API client
│   │   ├── hooks/
│   │   │   └── useGlossaryData.ts # Glossary data hook
│   │   ├── components/
│   │   │   └── acronymglossary.tsx # Glossary dashboard (search, filters, cards/table views)
│   │   └── index.css              # Global styles
│   ├── vite.config.ts             # Vite configuration
│   ├── package.json
│   ├── index.html
│   └── tsconfig.json
│
└── acronymsglossary.tsx           # Original standalone reference component
```

---

## Architecture

- **Backend** (`Deliverable5/backend/`): TypeScript Express server running on port `4002`. Exposes `/api/glossary`, serving the category list and full set of glossary terms as JSON. CORS enabled for frontend development.
- **Frontend** (`Deliverable5/frontend/`): React 18 + Vite SPA. Fetches category and term data from the backend API on load. Supports live search, category filtering, and toggling between a card view (expandable, grouped by category) and a table view. Default dev port: `5174`.
- **Data Layer**: Backend stores glossary terms as a typed TypeScript array (`term`, `full`, `cat`, `plain`, `example`), served as JSON via REST API.

### Glossary Categories

1. **AI & Technology** — AI/ML concepts, explainability, infrastructure, security
2. **Compliance & Regulation** — Regulatory bodies, mandatory reports, due diligence
3. **Financial Crime** — Typologies, laundering techniques, fraud patterns
4. **Architecture & Systems** — Architecture frameworks, data platforms, security models
5. **Project & Team** — Project/team naming, delivery artifacts
6. **Governance & Risk** — Accountability frameworks, risk roles, oversight metrics

---

## Getting Started

### Prerequisites

Ensure Node.js (v18+) is installed. On corporate/proxy networks, configure npm to use your organization's CA certificate:

**Option A — CA certificate file:**
```bash
npm config set cafile "C:\path\to\your-ca-bundle.crt"
```

**Option B — Disable strict SSL (trusted networks only):**
```bash
npm config set strict-ssl false
```

**Option C — Per-session environment variable:**
```bash
export NODE_EXTRA_CA_CERTS="C:\path\to\your-ca-bundle.crt"
```

### Installation & Dev Start

Start the **backend first**, then the frontend in a second terminal.

**Terminal 1 — Backend:**
```bash
cd "Deliverable5/backend"
npm install
npm run dev
```

The backend will be available at `http://localhost:4002` with health check at `/api/health`.

**Terminal 2 — Frontend:**
```bash
cd "Deliverable5/frontend"
npm install
npm run dev
```

Open `http://localhost:5174` in your browser.

---

## Environment Variables

**Backend** (`Deliverable5/backend/.env`, optional):
```
PORT=4002
```

If `PORT` is not set, defaults to `4002`.

**Frontend** (`Deliverable5/frontend/.env`, optional):
```
VITE_API_URL=http://localhost:4002
```

If not set, the frontend defaults to `http://localhost:4002`.

---

## Scripts

### Backend (`Deliverable5/backend/`)

| Script | Command | Description |
|---|---|---|
| `dev` | `tsx watch src/index.ts` | Dev server with auto-restart on file changes |
| `build` | `tsc -p tsconfig.json` | Compile TypeScript to JavaScript |
| `start` | `node dist/index.js` | Production start (requires build first) |
| `typecheck` | `tsc --noEmit` | Type-check without emitting files |

### Frontend (`Deliverable5/frontend/`)

| Script | Command | Description |
|---|---|---|
| `dev` | `vite` | Dev server with HMR |
| `build` | `tsc -b && vite build` | Type-check + production build |
| `preview` | `vite preview` | Preview production build locally |
| `typecheck` | `tsc -b --noEmit` | Type-check without emitting files |

---

## Key Files

| File | Purpose |
|---|---|
| `Deliverable5/backend/src/index.ts` | Express server initialization, middleware, routes setup |
| `Deliverable5/backend/src/routes/glossary.ts` | REST endpoint for `/api/glossary` |
| `Deliverable5/backend/src/data/terms.ts` | Categories and glossary term definitions |
| `Deliverable5/frontend/src/App.tsx` | Root React component |
| `Deliverable5/frontend/src/api/client.ts` | API client for fetching glossary data |
| `Deliverable5/frontend/src/hooks/useGlossaryData.ts` | Data-fetching hook (loading/error/data state) |
| `Deliverable5/frontend/src/components/acronymglossary.tsx` | Glossary dashboard — search, category filters, cards/table views |
| `Deliverable5/frontend/vite.config.ts` | Vite dev server configuration |

---

## API Endpoints

### Health Check
```
GET /api/health
```
Returns `{ status: "ok" }` if server is running.

### Get Glossary
```
GET /api/glossary
```
Returns categories and all glossary terms:
```json
{
  "categories": ["All", "AI & Technology", "Compliance & Regulation", "..."],
  "terms": [
    {
      "term": "AI",
      "full": "Artificial Intelligence",
      "cat": "AI & Technology",
      "plain": "Computer systems that can perform tasks that normally require human thinking...",
      "example": "Our system uses AI to read thousands of transactions and flag suspicious ones..."
    }
  ]
}
```

---

## Development Workflow

1. **Backend changes**: Modify files in `Deliverable5/backend/src/`. `tsx watch` will auto-restart the server.
2. **Frontend changes**: Modify files in `Deliverable5/frontend/src/`. Vite HMR will update the browser automatically.
3. **Type checking**: Run `npm run typecheck` in either directory to validate TypeScript without building.
4. **Adding a new term**:
   - Add an entry to the `TERMS` array in `backend/src/data/terms.ts` (include `term`, `full`, `cat`, `plain`, `example`)
   - If it belongs to a new category, add the category name to `CATEGORIES` and a color to `CAT_COLORS` in `frontend/src/components/acronymglossary.tsx`

---

## Troubleshooting

### Port Already in Use
If port 4002 (backend) or 5174 (frontend) is already in use:
- **Backend**: Set `PORT` environment variable (e.g., `PORT=4003 npm run dev`)
- **Frontend**: Vite will auto-select an available port; check console output

### API Connection Errors
Verify backend is running and CORS is enabled. Check backend console for error messages. Ensure `/api/glossary` requests in browser DevTools show successful responses from `http://localhost:4002`.

### Module Not Found
Run `npm install` in both `backend/` and `frontend/` directories. Clear `node_modules` and reinstall if issues persist.

---

## Production Build

### Backend
```bash
cd Deliverable5/backend
npm run build
npm start
```

### Frontend
```bash
cd Deliverable5/frontend
npm run build
npm run preview  # Test production build locally
```

Production builds output to `frontend/dist/` and `backend/dist/`. Deploy as needed for your hosting environment.

---

## License

See [LICENSE](../LICENSE) in the repository root.

---

## Contact & Support

For questions or issues with Deliverable 5, refer to the main project [README](../README.md) or contact the project maintainers.
