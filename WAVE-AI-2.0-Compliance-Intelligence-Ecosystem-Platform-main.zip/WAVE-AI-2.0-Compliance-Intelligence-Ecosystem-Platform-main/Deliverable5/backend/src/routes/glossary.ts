import { Router } from "express";
import { CATEGORIES, TERMS } from "../data/terms";

export const glossaryRouter = Router();

// GET /api/glossary — categories + all terms
glossaryRouter.get("/", (_req, res) => {
  res.json({ categories: CATEGORIES, terms: TERMS });
});
