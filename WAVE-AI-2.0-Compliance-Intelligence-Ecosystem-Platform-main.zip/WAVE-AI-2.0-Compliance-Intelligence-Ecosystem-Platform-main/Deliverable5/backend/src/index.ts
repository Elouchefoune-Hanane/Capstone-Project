import express from "express";
import cors from "cors";
import { glossaryRouter } from "./routes/glossary";

const app = express();
const PORT = process.env.PORT ? Number(process.env.PORT) : 4002;

app.use(cors());
app.use(express.json());

app.get("/api/health", (_req, res) => {
  res.json({ status: "ok" });
});

app.use("/api/glossary", glossaryRouter);

app.listen(PORT, () => {
  console.log(`WAVE AI glossary API listening on http://localhost:${PORT}`);
});
